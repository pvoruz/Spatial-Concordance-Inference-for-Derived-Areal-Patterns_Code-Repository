# Canonical singleton-vs-pair MSR sensitivity v3

This version supersedes the historical development output and v2 repair attempt.

Why v3 exists:
- the historical output did not correspond exactly to the archived script revision;
- pair-MSR depends on the eigenvector pairing/order inside near-degenerate Moran eigenspaces;
- reconstructing the basis at runtime therefore introduced BLAS/LAPACK orientation sensitivity.

Repair:
- the exact nonconstant, eigenvalue-ordered MEM basis is frozen at
  `configs/FROZEN_MEM_BASIS_MSR_AUDIT.npz`;
- the basis is tied to the fictitious NOT-GENEVA support SHA-256 and graph k=6;
- all random seeds are explicit;
- the sensitivity is fixed at 1,000 replicates per rho and B=199 null surrogates,
  appropriate for a secondary algorithmic sensitivity while keeping full reruns tractable.

The v3 summary was independently reproduced twice byte-for-byte before being
accepted as the canonical reference output.
