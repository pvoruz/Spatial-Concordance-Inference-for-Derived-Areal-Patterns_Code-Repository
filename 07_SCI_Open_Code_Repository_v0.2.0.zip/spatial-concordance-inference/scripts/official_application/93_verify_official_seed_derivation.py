#!/usr/bin/env python3
from pathlib import Path
import hashlib, json
REPO=Path(__file__).resolve().parents[2]
CONFIGS=REPO/'configs'
manifest=json.loads((CONFIGS/'OFFICIAL_SEED_DERIVATION.json').read_text())
cfg=json.loads((CONFIGS/'config_publication.json').read_text())
salt=manifest['salt']
expected={}
for cfg_key,label in manifest['labels'].items():
    expected[cfg_key]=int.from_bytes(hashlib.sha256((salt+'|'+label).encode()).digest()[:8],'big')%(2**32)
if expected!=manifest['derived_seeds']:
    raise SystemExit('Seed manifest derivation mismatch')
for k,v in expected.items():
    if int(cfg.get(k,-1))!=int(v):
        raise SystemExit(f'Publication config seed mismatch for {k}: {cfg.get(k)} != {v}')
if cfg.get('publication_seeds_pretested_on_dry_run') is not False:
    raise SystemExit('Publication seed guardrail must state publication_seeds_pretested_on_dry_run=false')
print(json.dumps({'status':'PASS','salt_sha256':hashlib.sha256(salt.encode()).hexdigest(),'derived_seeds':expected,'publication_seeds_pretested_on_dry_run':False},indent=2))
