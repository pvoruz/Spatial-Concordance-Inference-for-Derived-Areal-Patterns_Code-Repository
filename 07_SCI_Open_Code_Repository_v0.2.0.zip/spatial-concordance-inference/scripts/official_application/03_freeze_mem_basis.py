#!/usr/bin/env python3
"""Freeze the exact MEM eigenbasis used by SCI.

Archiving V removes dependence of downstream MSR p-values on eigenvector
orientation choices made by BLAS/LAPACK inside degenerate eigenspaces.
The basis is tied to a support SHA-256 and graph-k value.
"""
from __future__ import annotations
import argparse, hashlib, importlib.util, json
from pathlib import Path
import numpy as np

HERE=Path(__file__).resolve().parent

def sha(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for b in iter(lambda:f.read(1048576),b''): h.update(b)
    return h.hexdigest()

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--support',required=True)
    ap.add_argument('--graph-k',type=int,required=True)
    ap.add_argument('--out',required=True)
    a=ap.parse_args()
    spec=importlib.util.spec_from_file_location('runner',HERE/'02_run_semi_synthetic_tbi.py')
    r=importlib.util.module_from_spec(spec); spec.loader.exec_module(r)
    raw=json.loads(Path(a.support).read_text()); props=[f['properties'] for f in raw['features']]
    x=np.asarray([[float(q['SCI_CENTROID_X']),float(q['SCI_CENTROID_Y'])] for q in props])
    W=r.graph(x,a.graph_k); V=r.basis(W)
    out=Path(a.out); out.parent.mkdir(parents=True,exist_ok=True)
    np.savez_compressed(out,V=V,support_sha256=np.array(sha(a.support)),graph_k=np.array(a.graph_k,dtype=np.int64))
    print(out)
    print('support_sha256',sha(a.support))
    print('shape',V.shape)
if __name__=='__main__': main()
