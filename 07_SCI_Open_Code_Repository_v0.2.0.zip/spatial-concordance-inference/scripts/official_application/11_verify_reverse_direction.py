#!/usr/bin/env python3
"""Recompute the post hoc reverse-direction Geneva sensitivity from frozen inputs."""
import argparse, importlib.util, json, math
from pathlib import Path
import numpy as np
REPO=Path(__file__).resolve().parents[2]
SCRIPT=Path(__file__).resolve().parent/'02_run_semi_synthetic_tbi.py'
spec=importlib.util.spec_from_file_location('r',SCRIPT); r=importlib.util.module_from_spec(spec); spec.loader.exec_module(r)

def main():
 ap=argparse.ArgumentParser(); ap.add_argument('--support',default=str(REPO/'data/official_support/prepared_support.geojson')); ap.add_argument('--config',default=str(REPO/'configs/config_publication.json')); ap.add_argument('--out',default=str(REPO/'reference_outputs/reverse_direction_results.json')); a=ap.parse_args()
 cfg=json.loads(Path(a.config).read_text()); raw=json.loads(Path(a.support).read_text()); P=[f['properties'] for f in raw['features']]
 x=np.asarray([[float(q['SCI_CENTROID_X']),float(q['SCI_CENTROID_Y'])] for q in P]); area=np.asarray([float(q['SCI_AREA_M2']) for q in P]); pw=np.asarray([float(q.get('SCI_POP_18_59',0) or 0) for q in P]); ps=np.asarray([float(q.get('SCI_POP_60PLUS',0) or 0) for q in P]); padult=pw+ps
 W=r.graph(x,int(cfg['spatial_graph_k'])); fb=REPO/'configs/FROZEN_MEM_BASIS_OFFICIAL_GENEVA.npz'; V=np.load(fb,allow_pickle=False)['V'] if fb.exists() else r.basis(W); rw,rs=r.gp(x,float(cfg['latent_cross_age_rho']),float(cfg['risk_spatial_range_m']),int(cfg['risk_seed'])); cw=r.draw(pw,rw,393,float(cfg['beta']),int(cfg['event_seed_work'])); cs=r.draw(ps,rs,678,float(cfg['beta']),int(cfg['event_seed_senior'])); sw=r.smooth(cw,pw,x,float(cfg['kernel_bandwidth_m'])); ss=r.smooth(cs,ps,x,float(cfg['kernel_bandwidth_m']))
 q=float(cfg['primary_top_fraction']); hs=r.top(ss,q); B=int(cfg['nnull']); ens_un=r.surrogates(sw,V,B,int(cfg['null_seed_unconditional']))
 mean1,res1,coef1,z1,o1=r.population_mean_structure(sw,padult,degree=1); mean3,res3,coef3,z3,o3=r.population_mean_structure(sw,padult,degree=3); signs=r.msr_sign_matrix(V.shape[1],B,int(cfg['null_seed_population'])); ens_p1=r.surrogate_ensemble(sw,V,B,int(cfg['null_seed_population']),mean=mean1,signs=signs); ens_p3=r.surrogate_ensemble(sw,V,B,int(cfg['null_seed_population']),mean=mean3,signs=signs)
 ju,pu,_=r.p_fixed_from_ensemble(hs,sw,q,ens_un); ja,pa,_=r.p_fixed_from_ensemble(hs,sw,q,ens_un,area); jp,pp,_=r.p_fixed_from_ensemble(hs,sw,q,ens_p1,padult); jp3,pp3,_=r.p_fixed_from_ensemble(hs,sw,q,ens_p3,padult)
 thr=math.log(float(cfg['secondary_rr_threshold'])); hsa=ss>thr; ju2,pu2,hwa,_=r.p_abs_from_ensemble(hsa,sw,thr,ens_un); ja2,pa2,_,_=r.p_abs_from_ensemble(hsa,sw,thr,ens_un,area); jp2,pp2,_,_=r.p_abs_from_ensemble(hsa,sw,thr,ens_p1,padult); jp23,pp23,_,_=r.p_abs_from_ensemble(hsa,sw,thr,ens_p3,padult)
 out={'primary_unit_jaccard':float(ju),'primary_unit_p_reverse':float(pu),'primary_area_jaccard':float(ja),'primary_area_p_reverse':float(pa),'primary_population_jaccard':float(jp),'primary_population_p_reverse_linear':float(pp),'primary_population_p_reverse_cubic':float(pp3),'secondary_unit_jaccard':float(ju2),'secondary_unit_p_reverse':float(pu2),'secondary_area_jaccard':float(ja2),'secondary_area_p_reverse':float(pa2),'secondary_population_jaccard':float(jp2),'secondary_population_p_reverse_linear':float(pp2),'secondary_population_p_reverse_cubic':float(pp23)}
 Path(a.out).parent.mkdir(parents=True,exist_ok=True); Path(a.out).write_text(json.dumps(out,indent=2)); print(json.dumps(out,indent=2))
if __name__=='__main__': main()
