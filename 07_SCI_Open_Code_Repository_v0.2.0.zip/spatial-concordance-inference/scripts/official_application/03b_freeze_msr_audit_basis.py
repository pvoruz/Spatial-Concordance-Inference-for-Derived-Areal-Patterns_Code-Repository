#!/usr/bin/env python3
"""Freeze the exact eigenvalue-ordered nonconstant MEM basis used by the
singleton-vs-pair MSR algorithm sensitivity audit.

This basis is specific to the fictitious NOT-GENEVA support and graph k=6.
Archiving it removes BLAS/LAPACK orientation ambiguity in repeated/near-repeated
eigenspaces, which matters for pair-MSR because coefficients are paired in
basis order.
"""
from __future__ import annotations
import argparse, hashlib, importlib.util, json, math
from pathlib import Path
import numpy as np
from scipy.linalg import eigh

HERE=Path(__file__).resolve().parent
REPO=HERE.parents[1]
V5=REPO/'archive'/'v5'/'extracted_code'/'geneva_semi_synthetic_v5'

def sha(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for b in iter(lambda:f.read(1048576),b''): h.update(b)
    return h.hexdigest()

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--support',default=str(V5/'dry_run'/'synthetic_support_NOT_GENEVA.geojson'))
    ap.add_argument('--graph-k',type=int,default=6)
    ap.add_argument('--out',default=str(REPO/'configs'/'FROZEN_MEM_BASIS_MSR_AUDIT.npz'))
    a=ap.parse_args()
    spec=importlib.util.spec_from_file_location('runner',HERE/'02_run_semi_synthetic_tbi.py')
    r=importlib.util.module_from_spec(spec); spec.loader.exec_module(r)
    raw=json.loads(Path(a.support).read_text()); props=[f['properties'] for f in raw['features']]
    x=np.asarray([[float(q['SCI_CENTROID_X']),float(q['SCI_CENTROID_Y'])] for q in props])
    W=r.graph(x,a.graph_k)
    S=(W+W.T)/2
    C=S-S.mean(1,keepdims=True)-S.mean(0,keepdims=True)+S.mean()
    lam,V=eigh(C,check_finite=False)
    const_idx=int(np.argmax(np.abs(V.T@np.ones(len(V))/math.sqrt(len(V)))))
    keep=np.arange(len(lam))!=const_idx
    lam,V=lam[keep],V[:,keep]
    order=np.argsort(lam)[::-1]; lam,V=lam[order],V[:,order]
    out=Path(a.out); out.parent.mkdir(parents=True,exist_ok=True)
    np.savez_compressed(out,V=V,eigenvalues=lam,support_sha256=np.array(sha(a.support)),graph_k=np.array(a.graph_k,dtype=np.int64))
    print(out)
    print('support_sha256',sha(a.support))
    print('basis_sha256',sha(out))
    print('shape',V.shape)
if __name__=='__main__': main()
