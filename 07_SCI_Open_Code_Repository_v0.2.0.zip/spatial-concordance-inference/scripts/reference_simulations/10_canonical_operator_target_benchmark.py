#!/usr/bin/env python3
"""Canonical reproducible benchmark for Spatial Concordance Inference.

This script replaces the non-rerunnable developmental fixed/variable-mass
benchmarks in the manuscript.  It is deliberately self-contained and uses the
fictitious 158-unit support bundled with the v5 development archive.

Inferential targets compared
----------------------------
IID-pattern       : mass-preserving unrestricted label randomization.
Pattern-MSR       : singleton MSR applied to the observed binary pattern,
                    followed by top-|H_B| reclassification; conditions on
                    observed hotspot mass while retaining spatial structure.
SCI               : singleton MSR applied upstream to the continuous surface,
                    then the original classification rule is reapplied.
Generative        : directional marginal reference generated from the frozen
                    surface model under rho=0, conditional only on H_A.

The surface generator is aligned with the null engine by construction.  It
uses the full non-constant Moran eigenbasis and chooses a deterministic spectral
weight parameter such that the expected global Moran I is 0.55. This makes the
calibration experiment transparent and exactly rerunnable without hidden
historical tuning parameters.
"""
from __future__ import annotations
import argparse, hashlib, importlib.util, json, math, os, platform, sys
from pathlib import Path
import numpy as np
import pandas as pd
import scipy
from scipy.linalg import eigh
from scipy.stats import norm

ROOT = Path(__file__).resolve().parents[2]
V5_DEFAULT = ROOT / "archive" / "v5" / "extracted_code" / "geneva_semi_synthetic_v5"


def sha256(path: Path) -> str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1024*1024), b''): h.update(block)
    return h.hexdigest()


def load_runner(v5root: Path):
    p=v5root/'scripts'/'02_run_semi_synthetic_tbi.py'
    spec=importlib.util.spec_from_file_location('runner',p)
    m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m


def wilson(k,n,alpha=.05):
    z=norm.ppf(1-alpha/2); ph=k/n; den=1+z*z/n
    ctr=(ph+z*z/(2*n))/den
    half=z*math.sqrt(ph*(1-ph)/n+z*z/(4*n*n))/den
    return ctr-half,ctr+half


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--reps',type=int,default=2000)
    ap.add_argument('--B',type=int,default=499)
    ap.add_argument('--rho-alt',type=float,default=.50)
    ap.add_argument('--target-moran',type=float,default=.55)
    ap.add_argument('--outdir',default=str(ROOT/'reference_outputs'/'canonical_benchmark_v1'))
    ap.add_argument('--v5root',default=str(V5_DEFAULT))
    args=ap.parse_args()
    out=Path(args.outdir); out.mkdir(parents=True,exist_ok=True)
    v5root=Path(args.v5root)
    support=v5root/'dry_run'/'synthetic_support_NOT_GENEVA.geojson'
    raw=json.loads(support.read_text()); P=[f['properties'] for f in raw['features']]
    x=np.array([[q['SCI_CENTROID_X'],q['SCI_CENTROID_Y']] for q in P],float)
    m=len(x); k=max(1,int(round(.10*m))); abs_thr=float(norm.ppf(.90))
    r=load_runner(v5root); W=r.graph(x,6)
    S=(W+W.T)/2
    C=S-S.mean(1,keepdims=True)-S.mean(0,keepdims=True)+S.mean()
    lam,V=eigh(C,check_finite=False)
    const_idx=int(np.argmax(np.abs(V.T@np.ones(m)/math.sqrt(m))))
    keep=np.arange(m)!=const_idx; lam,V=lam[keep],V[:,keep]
    order=np.argsort(lam)[::-1]; lam,V=lam[order],V[:,order]
    scale=float(np.std(lam))
    def exp_moran(eta):
        q=np.exp(eta*lam/scale)
        return (m/W.sum())*float(np.sum(lam*q)/np.sum(q))
    lo,hi=-8.,8.
    for _ in range(100):
        mid=(lo+hi)/2
        if exp_moran(mid)<args.target_moran: lo=mid
        else: hi=mid
    eta=(lo+hi)/2; q=np.exp(eta*lam/scale); amp=np.sqrt(q); surf_sd=math.sqrt(float(np.sum(q)/m))

    def moran(s):
        z=s-s.mean(); return (m/W.sum())*float((z@(W@z))/(z@z))
    def gen_pair(rng,rho):
        za=rng.normal(size=m-1); ze=rng.normal(size=m-1)
        zb=rho*za+math.sqrt(max(0.,1-rho*rho))*ze
        return (V@(amp*za))/surf_sd, (V@(amp*zb))/surf_sd
    def top(s,kk=k):
        idx=np.argpartition(s,m-kk)[m-kk:]; h=np.zeros(m,bool); h[idx]=True; return h
    def classify(s,op): return top(s) if op=='top10' else s>abs_thr
    def jac(a,b):
        u=int((a|b).sum()); return float((a&b).sum()/u) if u else np.nan
    def msr_ens(s,B,rng):
        c=V.T@(s-s.mean()); signs=rng.choice(np.array([-1.,1.]),size=(len(c),B))
        return (s.mean()+V@(c[:,None]*signs)).T
    def null_js(hA,HB):
        inter=HB@hA.astype(np.int16); mass=HB.sum(1); den=hA.sum()+mass-inter
        return np.divide(inter,den,out=np.zeros_like(inter,dtype=float),where=den>0)
    def p_iid(hA,hB,B,rng):
        obs=jac(hA,hB); mass=int(hB.sum()); HB=np.zeros((B,m),bool)
        for j in range(B): HB[j,rng.choice(m,mass,replace=False)]=True
        js=null_js(hA,HB); return obs,(1+int(np.sum(js>=obs)))/(B+1),float(np.std(HB.sum(1)))
    def p_pattern_msr(hA,hB,B,rng):
        obs=jac(hA,hB); mass=int(hB.sum()); ens=msr_ens(hB.astype(float),B,rng); HB=np.zeros((B,m),bool)
        if mass>0:
            idx=np.argpartition(ens,m-mass,axis=1)[:,m-mass:]
            HB[np.arange(B)[:,None],idx]=True
        js=null_js(hA,HB); return obs,(1+int(np.sum(js>=obs)))/(B+1),float(np.std(HB.sum(1)))
    def p_sci(hA,sB,op,B,rng):
        hB=classify(sB,op); obs=jac(hA,hB)
        if hA.sum()==0 or hB.sum()==0: return obs,1.0,np.nan
        ens=msr_ens(sB,B,rng)
        if op=='top10':
            HB=np.zeros((B,m),bool); idx=np.argpartition(ens,m-k,axis=1)[:,m-k:]; HB[np.arange(B)[:,None],idx]=True
        else: HB=ens>abs_thr
        js=null_js(hA,HB); return obs,(1+int(np.sum(js>=obs)))/(B+1),float(np.std(HB.sum(1)))
    def p_gen(hA,hB,op,B,rng):
        obs=jac(hA,hB); Z=rng.normal(size=(m-1,B)); ens=(V@(amp[:,None]*Z)).T/surf_sd
        if op=='top10':
            HB=np.zeros((B,m),bool); idx=np.argpartition(ens,m-k,axis=1)[:,m-k:]; HB[np.arange(B)[:,None],idx]=True
        else: HB=ens>abs_thr
        js=null_js(hA,HB); return obs,(1+int(np.sum(js>=obs)))/(B+1),float(np.std(HB.sum(1)))

    rows=[]
    base_seed=260913000
    for condition,rho in [('H0',0.0),('H1',args.rho_alt)]:
        rng=np.random.default_rng(base_seed+(0 if condition=='H0' else 1))
        for rep in range(args.reps):
            a,b=gen_pair(rng,rho); IA,IB=moran(a),moran(b)
            for oi,op in enumerate(['top10','absolute90']):
                hA=classify(a,op); hB=classify(b,op)
                methods=[
                    ('IID-pattern',p_iid(hA,hB,args.B,np.random.default_rng(10_000_000+rep+oi*1_000_000+(0 if condition=='H0' else 5_000_000)))),
                    ('Pattern-MSR',p_pattern_msr(hA,hB,args.B,np.random.default_rng(20_000_000+rep+oi*1_000_000+(0 if condition=='H0' else 5_000_000)))),
                    ('SCI',p_sci(hA,b,op,args.B,np.random.default_rng(30_000_000+rep+oi*1_000_000+(0 if condition=='H0' else 5_000_000)))),
                    ('Generative',p_gen(hA,hB,op,args.B,np.random.default_rng(40_000_000+rep+oi*1_000_000+(0 if condition=='H0' else 5_000_000)))),
                ]
                for method,(J,pv,mass_sd) in methods:
                    rows.append({'condition':condition,'rho':rho,'rep':rep,'operator':op,'method':method,
                                 'J_obs':J,'p_value':pv,'mass_A':int(hA.sum()),'mass_B':int(hB.sum()),
                                 'null_mass_sd':mass_sd,'moran_A':IA,'moran_B':IB})
    d=pd.DataFrame(rows); d.to_csv(out/'canonical_benchmark_replicates.csv',index=False)
    summ=[]
    for (cond,op,meth),g in d.groupby(['condition','operator','method'],sort=False):
        reject=(g.p_value<=.05); lo,hi=wilson(int(reject.sum()),len(g))
        summ.append({'condition':cond,'operator':op,'method':meth,'reps':len(g),'B':args.B,
                     'rejection_rate':float(reject.mean()),'ci95_low':lo,'ci95_high':hi,
                     'mean_J':float(g.J_obs.mean()),'mean_mass_A':float(g.mass_A.mean()),
                     'mean_mass_B':float(g.mass_B.mean()),'mean_null_mass_sd':float(g.null_mass_sd.mean(skipna=True)),
                     'mean_moran_A':float(g.moran_A.mean()),'mean_moran_B':float(g.moran_B.mean())})
    s=pd.DataFrame(summ); s.to_csv(out/'canonical_benchmark_summary.csv',index=False)
    script=Path(__file__).resolve()
    manifest={
        'status':'CANONICAL_BENCHMARK_V1_COMPLETE','clinical_interpretation':False,
        'support':'synthetic_support_NOT_GENEVA.geojson','support_sha256':sha256(support),
        'script_sha256':sha256(script),'reps_per_condition':args.reps,'B':args.B,'alpha':.05,
        'rho_H0':0.0,'rho_H1':args.rho_alt,'m':m,'k_top10':k,'absolute_threshold_z':abs_thr,
        'target_expected_moran':args.target_moran,'spectral_eta':eta,'expected_moran':exp_moran(eta),
        'seeds':{'observed_base':base_seed,'iid':10000000,'pattern_msr':20000000,'sci':30000000,'generative':40000000},
        'environment':{'python':sys.version,'numpy':np.__version__,'scipy':scipy.__version__,'pandas':pd.__version__,
                       'platform':platform.platform(),'OPENBLAS_NUM_THREADS':os.environ.get('OPENBLAS_NUM_THREADS'),
                       'OMP_NUM_THREADS':os.environ.get('OMP_NUM_THREADS'),'MKL_NUM_THREADS':os.environ.get('MKL_NUM_THREADS')},
        'definitions':{
            'Pattern-MSR':'singleton MSR of observed binary pattern followed by fixed observed-mass reclassification',
            'SCI':'singleton MSR of continuous surface followed by original operator',
            'Generative':'independent continuous surface draws from the frozen rho=0 spectral generator conditional on H_A'
        }
    }
    (out/'canonical_benchmark_manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    print(s.to_string(index=False))

if __name__=='__main__': main()
