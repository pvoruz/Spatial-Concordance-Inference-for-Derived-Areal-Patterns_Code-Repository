# Reference simulation implementations

These scripts are **reconstructed reference implementations**, not historical source files, unless explicitly stated otherwise.

They encode the published methodological logic using the clean `src/sci/` library and are intended to make the design transparent and reusable. The manuscript's archived numerical results remain tied to the versioned methodological audit trail.

For exact provenance, see `docs/CODE_PROVENANCE.md`.
