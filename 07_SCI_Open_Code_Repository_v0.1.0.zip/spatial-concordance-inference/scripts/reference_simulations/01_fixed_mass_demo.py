"""Reconstructed fixed-mass SCI demonstration.

This is not claimed to be the original historical script that generated the
manuscript's fixed-mass benchmark numbers.
"""
import numpy as np
from sci.spatial import knn_graph, moran_basis, singleton_msr_ensemble
from sci.patterns import top_fraction_pattern
from sci.metrics import weighted_jaccard

def one_run(seed=1, n_units=160, B=99, rho=0.0):
    rng=np.random.default_rng(seed)
    coords=rng.uniform(0, 1, size=(n_units,2))
    a=rng.normal(size=n_units)
    b=rho*a + np.sqrt(max(0,1-rho*rho))*rng.normal(size=n_units)
    W=knn_graph(coords,6); _,V,_=moran_basis(W)
    ha=top_fraction_pattern(a,.10)
    hb=top_fraction_pattern(b,.10)
    obs=weighted_jaccard(ha,hb)
    ens=singleton_msr_ensemble(b,V,B,seed+10_000)
    null=np.array([weighted_jaccard(ha,top_fraction_pattern(s,.10)) for s in ens])
    p=(1+(null>=obs).sum())/(B+1)
    return obs,p

if __name__=="__main__":
    print(one_run())
