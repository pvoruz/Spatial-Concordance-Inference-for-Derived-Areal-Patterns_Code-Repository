"""Reconstructed exact-N health-like semi-synthetic demo on fictitious support."""
import numpy as np
from sci.simulate import correlated_gaussian_fields, exact_multinomial_events, gaussian_log_rr_surface
from sci.patterns import top_fraction_pattern
from sci.metrics import weighted_jaccard

rng=np.random.default_rng(7)
m=158
coords=rng.uniform(0,20_000,size=(m,2))
pop_a=rng.integers(50,3000,size=m)
pop_b=rng.integers(20,1500,size=m)
r1,r2=correlated_gaussian_fields(coords,rho=.65,spatial_range=3500,seed=11)
c1=exact_multinomial_events(pop_a,r1,N=393,beta=.8,seed=12)
c2=exact_multinomial_events(pop_b,r2,N=678,beta=.8,seed=13)
s1=gaussian_log_rr_surface(c1,pop_a,coords,2500)
s2=gaussian_log_rr_surface(c2,pop_b,coords,2500)
h1=top_fraction_pattern(s1,.10)
h2=top_fraction_pattern(s2,.10)
print({"J_units": weighted_jaccard(h1,h2), "n_hot_1": int(h1.sum()), "n_hot_2": int(h2.sum())})
