"""Reconstructed variable-mass SCI demonstration.

The surface threshold is absolute so hotspot mass varies across surrogates.
This script illustrates the inferential mechanism; it is not the archived
historical source for the manuscript benchmark.
"""
import numpy as np
from sci.spatial import knn_graph, moran_basis, singleton_msr_ensemble
from sci.patterns import absolute_threshold_pattern
from sci.metrics import weighted_jaccard

def one_run(seed=2, n_units=160, B=99, rho=0.5, threshold=0.8):
    rng=np.random.default_rng(seed)
    coords=rng.uniform(0,1,size=(n_units,2))
    a=rng.normal(size=n_units)
    b=rho*a + np.sqrt(max(0,1-rho*rho))*rng.normal(size=n_units)
    W=knn_graph(coords,6); _,V,_=moran_basis(W)
    ha=absolute_threshold_pattern(a,threshold)
    hb=absolute_threshold_pattern(b,threshold)
    if not (0 < ha.sum() < n_units and 0 < hb.sum() < n_units):
        return np.nan,1.0
    obs=weighted_jaccard(ha,hb)
    ens=singleton_msr_ensemble(b,V,B,seed+20_000)
    null=[]
    for s in ens:
        hs=absolute_threshold_pattern(s,threshold)
        null.append(weighted_jaccard(ha,hs))
    null=np.asarray(null,dtype=float)
    p=(1+np.nansum(null>=obs))/(B+1)
    return obs,p

if __name__=="__main__":
    print(one_run())
