"""Generate summary figures from numerical results documented in the audit trail.

This script uses documented aggregate results for manuscript/supplement panels.
It does not regenerate the simulations themselves.
"""
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt

OUT=Path("outputs/figures")
OUT.mkdir(parents=True,exist_ok=True)

# Fixed vs variable-mass benchmark
def grouped(path,title,labels,type1,power):
    x=np.arange(len(labels)); w=.38
    fig,ax=plt.subplots(figsize=(7,4.4))
    ax.bar(x-w/2,type1,w,label="Type-I error")
    ax.bar(x+w/2,power,w,label="Power")
    ax.axhline(.05,ls="--",lw=1)
    ax.set_xticks(x); ax.set_xticklabels(labels,rotation=25,ha="right")
    ax.set_ylabel("Probability"); ax.set_title(title); ax.legend(frameon=False)
    ax.grid(axis="y",alpha=.2)
    fig.savefig(path,dpi=300,bbox_inches="tight"); plt.close(fig)

grouped(OUT/"fixed_mass.png","Fixed-mass top-10%",
        ["IID","Arthur-pattern","Arthur-surface","SCI","Generative"],
        [.080,.039,.035,.042,.032],[.624,.466,.398,.440,.472])

grouped(OUT/"variable_mass.png","Variable-mass RR > 1.5",
        ["Arthur-pattern","Arthur-surface","SCI","Marginal generative"],
        [.048,.030,.059,.057],[.584,.528,.625,.659])

# Threshold robustness
thr=[1.3,1.5,2.0]
fig,ax=plt.subplots(figsize=(6.8,4.5))
ax.plot(thr,[.730,.625,.510],marker="o",label="SCI")
ax.plot(thr,[.735,.659,.525],marker="o",label="Marginal generative reference")
ax.plot(thr,[.690,.584,.435],marker="o",label="Arthur-pattern")
ax.plot(thr,[.590,.528,.400],marker="o",label="Arthur-surface")
ax.set_xlabel("RR threshold"); ax.set_ylabel("Power"); ax.legend(frameon=False)
ax.grid(axis="y",alpha=.2)
fig.savefig(OUT/"threshold_robustness.png",dpi=300,bbox_inches="tight"); plt.close(fig)

# Geneva directionality
labels=["Unit-count","True area","Population linear","Population cubic","RR>1.5 area"]
primary=[.0962,.0284,.1574,.1136,.0730]
reverse=[.1548,.1594,.1488,.0806,.0666]
x=np.arange(len(labels)); w=.36
fig,ax=plt.subplots(figsize=(8,4.7))
ax.bar(x-w/2,primary,w,label="Frozen primary direction")
ax.bar(x+w/2,reverse,w,label="Post hoc reverse direction")
ax.axhline(.05,ls="--",lw=1)
ax.set_xticks(x); ax.set_xticklabels(labels,rotation=15,ha="right")
ax.set_ylabel("Monte Carlo p-value"); ax.legend(frameon=False)
ax.grid(axis="y",alpha=.2)
fig.savefig(OUT/"geneva_directionality.png",dpi=300,bbox_inches="tight"); plt.close(fig)
