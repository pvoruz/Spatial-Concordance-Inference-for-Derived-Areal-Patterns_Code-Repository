# Manuscript-safe semi-synthetic health application — v2

The methodological case study uses a strict semi-synthetic design. Geographic support and population denominators are specified from the official Geneva SITG population-by-statistical-subsector layer (OCS_POPULATION_SSECTEUR; CH1903+/LV95, EPSG:2056), whereas all clinical geography is synthetic.

The synthetic sample is calibrated only to publicly reported aggregate characteristics of a Geneva hospitalized traumatic brain injury cohort: 1,071 hospitalized cases overall, including 678 adults aged 60 years or older and 393 adults aged 18–59 years. These counts constrain only the numbers of simulated events. No observed patient address, empirical hotspot polygon, cluster centroid, patient-level clinical trajectory, or unpublished spatial feature is used.

Within age stratum g,

(C_1g,...,C_mg) ~ Multinomial(N_g, pi_1g,...,pi_mg),

with

pi_ig = P_ig exp(beta R_ig) / sum_j P_jg exp(beta R_jg),

where P_ig is the official age-specific denominator and R_ig is a de novo seeded synthetic spatial-risk field generated independently of the empirical TBI map.

The primary pattern operator classifies the 10% of spatial units with the highest estimated log-relative risk. RR>1.5 is a secondary variable-mass operator and is not tuned if non-estimable.

Three overlap estimands are kept distinct. Unit-count Jaccard weights every statistical subsector equally. Area Jaccard uses the exact planar polygon area computed from the official LV95 geometry, with holes subtracted and MultiPolygon components summed. Population Jaccard weights each subsector by mapped adult population age 18 years or older.

For unit-count and area-based inference, a common continuous-surface MSR surrogate ensemble is generated and the pre-specified pattern operator is reapplied to every surrogate. For population-weighted inference, a separate conditional residual null is used. Before randomization, the senior log-relative-risk surface S_B is decomposed according to the pre-specified fixed-design model

S_B = m_B(P) + epsilon_B,

m_B(P) = b0 + b1 z[log(1 + P_18plus)].

The two coefficients are estimated once from the observed synthetic surface, the fitted mean component is then held fixed, and MSR is applied only to epsilon_B. Surrogate surfaces are reconstructed as S_B* = m_B(P) + epsilon_B*. The functional form is fixed before official execution and is not selected after inspection of the synthetic Geneva realization.

The same MSR surrogate ensemble is reused for all statistics that share a null model. This avoids additional Monte-Carlo variability from generating independent null ensembles for equivalent or closely related overlap statistics.

This application is a real-geography simulation and methodological demonstration. It must not be interpreted as an empirical replication, validation, or new localization result for TBI in Geneva.
