#!/usr/bin/env python3
import hashlib, json, urllib.parse, urllib.request
from datetime import datetime, timezone
from pathlib import Path

BASE='https://vector.sitg.ge.ch/arcgis/rest/services/OCS_POPULATION_SSECTEUR/FeatureServer/0/query'
PARAMS={
    'where':'1=1','outFields':'*','returnGeometry':'true','outSR':'2056','f':'geojson'
}
CATALOGUE='https://sitg.ge.ch/donnees/ocs-population-ssecteur'
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'data'/'OCS_POPULATION_SSECTEUR_EPSG2056.geojson'

def main():
    OUT.parent.mkdir(parents=True,exist_ok=True)
    url=BASE+'?'+urllib.parse.urlencode(PARAMS)
    req=urllib.request.Request(url,headers={'User-Agent':'Spatial-Concordance-Geneva/2.0'})
    with urllib.request.urlopen(req,timeout=180) as r:
        data=r.read()
    obj=json.loads(data)
    fs=obj.get('features',[])
    if obj.get('type')!='FeatureCollection' or not (100 <= len(fs) <= 1200):
        raise RuntimeError(f'Unexpected SITG response: type={obj.get("type")}, n={len(fs)}')
    OUT.write_bytes(data)
    manifest={
        'authority':'SITG / Republic and Canton of Geneva',
        'dataset':'OCS_POPULATION_SSECTEUR',
        'catalogue_url':CATALOGUE,
        'query_url':url,
        'accessed_utc':datetime.now(timezone.utc).isoformat(),
        'crs_requested':'EPSG:2056',
        'bytes':len(data),
        'sha256':hashlib.sha256(data).hexdigest(),
        'feature_count':len(fs),
        'status':'OFFICIAL_RAW_DOWNLOADED',
        'clinical_data_in_download':False
    }
    OUT.with_suffix('.fetch_manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    print(json.dumps(manifest,indent=2))

if __name__=='__main__': main()
