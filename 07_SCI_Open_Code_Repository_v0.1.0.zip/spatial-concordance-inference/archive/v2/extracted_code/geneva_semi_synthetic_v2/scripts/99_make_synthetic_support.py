#!/usr/bin/env python3
import json, math
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
rng=np.random.default_rng(20260911); fs=[]
X0=2_490_000.; Y0=1_115_000.
for r in range(14):
    for c in range(18):
        if ((r-6.5)/6.2)**2+((c-8.5)/8.0)**2>1 or (r<3 and c>12): continue
        x=X0+c*1000.; y=Y0+r*1000.; pop=max(50,int(rng.lognormal(7.3,.45)))
        senior=int(round(pop*np.clip(.20+.08*math.sin(c/2)+rng.normal(0,.025),.08,.42)))
        work=int(round(pop*np.clip(.60+rng.normal(0,.03),.45,.72)))
        fs.append({'type':'Feature','properties':{'SSECTEUR_7':f'FAKE{len(fs):03d}','DATE_REF':'SYNTHETIC','POP':pop,
            'SCI_POP_18_59':work,'SCI_POP_60PLUS':senior,'SCI_POP_18PLUS':work+senior,
            'SCI_AREA_M2':810000.0,'SCI_CENTROID_X':x+450.,'SCI_CENTROID_Y':y+450.,
            'source_mode':'synthetic_test_NOT_GENEVA'},
            'geometry':{'type':'Polygon','coordinates':[[[x,y],[x+900,y],[x+900,y+900],[x,y+900],[x,y]]]}})
dest=ROOT/'dry_run'/'synthetic_support_NOT_GENEVA.geojson'
dest.write_text(json.dumps({'type':'FeatureCollection','features':fs}),encoding='utf-8')
print('Created',len(fs),'fictitious units:',dest)
