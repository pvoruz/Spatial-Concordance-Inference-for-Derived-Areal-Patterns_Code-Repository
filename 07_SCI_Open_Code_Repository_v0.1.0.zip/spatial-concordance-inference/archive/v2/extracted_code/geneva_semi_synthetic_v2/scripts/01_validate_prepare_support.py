#!/usr/bin/env python3
import argparse, hashlib, json
from pathlib import Path
import pandas as pd
import numpy as np

WORK=['age_18','age_19','age_20_24','age_25_29','age_30_34','age_35_39',
      'age_40_44','age_45_49','age_50_54','age_55_59']
SEN=['age_60_64','age_65_69','age_70_74','age_75_79','age_80_84',
     'age_85_89','age_90_94','age_95_99','age_100_plus']
REQ=set(['date_ref','ssecteur_7','pop']+WORK+SEN)

def sha(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        for b in iter(lambda:f.read(1048576),b''): h.update(b)
    return h.hexdigest()

def coords(x):
    if isinstance(x,(list,tuple)):
        if len(x)>=2 and all(isinstance(v,(int,float)) for v in x[:2]):
            yield float(x[0]),float(x[1])
        else:
            for q in x: yield from coords(q)

def ring_metrics(ring):
    a=np.asarray(ring,float)
    if len(a)<3: raise ValueError('Polygon ring has fewer than 3 vertices')
    if np.allclose(a[0],a[-1]): a=a[:-1]
    if len(a)<3: raise ValueError('Degenerate polygon ring')
    b=np.roll(a,-1,axis=0)
    cross=a[:,0]*b[:,1]-b[:,0]*a[:,1]
    signed=.5*cross.sum()
    if abs(signed)<1e-9: raise ValueError('Zero-area polygon ring')
    cx=((a[:,0]+b[:,0])*cross).sum()/(6*signed)
    cy=((a[:,1]+b[:,1])*cross).sum()/(6*signed)
    return abs(signed),np.array([cx,cy],float)

def polygon_metrics(poly):
    if not poly: raise ValueError('Empty polygon coordinates')
    ae,ce=ring_metrics(poly[0]); area=ae; moment=ae*ce
    for hole in poly[1:]:
        ah,ch=ring_metrics(hole); area-=ah; moment-=ah*ch
    if area<=0: raise ValueError('Polygon area non-positive after holes')
    return area,moment/area

def geometry_metrics(g):
    if not g or 'coordinates' not in g: raise ValueError('Missing geometry')
    typ=g.get('type'); c=g['coordinates']
    if typ=='Polygon': return polygon_metrics(c)
    if typ=='MultiPolygon':
        vals=[polygon_metrics(p) for p in c]
        area=sum(v[0] for v in vals)
        if area<=0: raise ValueError('MultiPolygon area non-positive')
        cen=sum(v[0]*v[1] for v in vals)/area
        return area,cen
    raise ValueError(f'Unsupported geometry type: {typ}')

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--input',required=True); ap.add_argument('--output-dir',required=True)
    a=ap.parse_args(); inp=Path(a.input); out=Path(a.output_dir); out.mkdir(parents=True,exist_ok=True)
    raw=json.loads(inp.read_text(encoding='utf-8')); fs=raw.get('features',[])
    if raw.get('type')!='FeatureCollection' or not (100<=len(fs)<=1200):
        raise ValueError('Unexpected FeatureCollection / feature count.')
    rows=[]; xy=[]; seen=set(); outfs=[]
    for i,f in enumerate(fs):
        p={str(k).lower():v for k,v in f.get('properties',{}).items()}
        miss=REQ-set(p)
        if miss: raise ValueError(f'Feature {i} missing {sorted(miss)}')
        sid=str(p['ssecteur_7'])
        if sid in seen: raise ValueError(f'Duplicate SSECTEUR_7 {sid}')
        seen.add(sid)
        g=f.get('geometry'); pts=list(coords(g.get('coordinates') if g else None))
        if not pts: raise ValueError(f'Empty geometry {sid}')
        xy.extend(pts)
        area,cen=geometry_metrics(g)
        num=lambda k: 0.0 if p.get(k) is None else float(p[k])
        work=sum(num(k) for k in WORK); senior=sum(num(k) for k in SEN); pop=num('pop')
        if min(work,senior,pop)<0: raise ValueError('Negative denominator')
        P=dict(f.get('properties',{}))
        P['SCI_POP_18_59']=work; P['SCI_POP_60PLUS']=senior
        P['SCI_POP_18PLUS']=work+senior
        P['SCI_AREA_M2']=float(area); P['SCI_CENTROID_X']=float(cen[0]); P['SCI_CENTROID_Y']=float(cen[1])
        P['SCI_SOURCE']='SITG_OCS_POPULATION_SSECTEUR'
        outfs.append({'type':'Feature','properties':P,'geometry':g})
        rows.append([sid,str(p['date_ref']),pop,work,senior,work+senior,area,cen[0],cen[1]])
    z=np.asarray(xy,float); xmin,ymin=z.min(0); xmax,ymax=z.max(0)
    if not (2.3e6<xmin<2.7e6 and 2.3e6<xmax<2.7e6 and 1.0e6<ymin<1.3e6 and 1.0e6<ymax<1.3e6):
        raise ValueError(f'Not plausible EPSG:2056 bounds: {xmin,ymin,xmax,ymax}')
    df=pd.DataFrame(rows,columns=['ssecteur_7','date_ref','pop','pop_18_59','pop_60plus','pop_18plus','area_m2','centroid_x','centroid_y'])
    dates=[x for x in df.date_ref.unique() if x and x.lower()!='none']
    if len(dates)!=1: raise ValueError(f'Expected one DATE_REF, found {dates}')
    dest=out/'prepared_support.geojson'
    dest.write_text(json.dumps({'type':'FeatureCollection','features':outfs},separators=(',',':')),encoding='utf-8')
    df.to_csv(out/'support_denominators.csv',index=False)
    m={'source':'SITG OCS_POPULATION_SSECTEUR','source_sha256':sha(inp),'prepared_sha256':sha(dest),
       'date_ref':dates[0],'feature_count':len(fs),'crs':'EPSG:2056','bounds':[xmin,ymin,xmax,ymax],
       'mapped_population_total':float(df['pop'].sum()),'mapped_population_18_59':float(df['pop_18_59'].sum()),
       'mapped_population_60plus':float(df['pop_60plus'].sum()),'mapped_population_18plus':float(df['pop_18plus'].sum()),
       'mapped_polygon_area_m2':float(df['area_m2'].sum()),'zero_denominator_18_59':int((df.pop_18_59<=0).sum()),
       'zero_denominator_60plus':int((df.pop_60plus<=0).sum()),
       'area_definition':'planar polygon area in official LV95/EPSG:2056 geometry; holes subtracted; MultiPolygons summed',
       'centroid_definition':'area-weighted polygon centroid in LV95/EPSG:2056',
       'status':'OFFICIAL_SUPPORT_VALIDATED'}
    (out/'support_manifest.json').write_text(json.dumps(m,indent=2),encoding='utf-8')
    print(json.dumps(m,indent=2))
if __name__=='__main__': main()
