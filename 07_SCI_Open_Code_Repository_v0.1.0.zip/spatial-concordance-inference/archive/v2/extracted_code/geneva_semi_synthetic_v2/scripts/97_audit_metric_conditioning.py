#!/usr/bin/env python3
"""Deterministic guardrail tests for geometry weights and conditional residual SCI."""
import importlib.util, json
from pathlib import Path
import numpy as np

ROOT=Path(__file__).resolve().parents[1]

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m
v=load('validator',ROOT/'scripts'/'01_validate_prepare_support.py')
r=load('runner',ROOT/'scripts'/'02_run_semi_synthetic_tbi.py')

checks={}
# 10x10 square with 2x2 hole -> area 96, centroid (5,5)
g={'type':'Polygon','coordinates':[
 [[0,0],[10,0],[10,10],[0,10],[0,0]],
 [[4,4],[6,4],[6,6],[4,6],[4,4]]
]}
a,c=v.geometry_metrics(g); checks['polygon_hole_area_pass']=bool(abs(a-96)<1e-9); checks['polygon_hole_centroid_pass']=bool(np.max(np.abs(c-[5,5]))<1e-9)
# MultiPolygon: square area 4 centered (1,1) + square area 1 centered (10.5,.5)
g2={'type':'MultiPolygon','coordinates':[
 [[[0,0],[2,0],[2,2],[0,2],[0,0]]],
 [[[10,0],[11,0],[11,1],[10,1],[10,0]]]
]}
a2,c2=v.geometry_metrics(g2); target=(4*np.array([1.,1.])+1*np.array([10.5,.5]))/5
checks['multipolygon_area_pass']=bool(abs(a2-5)<1e-9); checks['multipolygon_centroid_pass']=bool(np.max(np.abs(c2-target))<1e-9)
# Weighted Jaccard must differ across unit, area and population weights.
A=np.array([1,1,0],bool); B=np.array([0,1,1],bool)
checks['unit_jaccard_expected']=bool(abs(r.jac(A,B)-1/3)<1e-12)
checks['area_jaccard_expected']=bool(abs(r.jac(A,B,np.array([1.,10.,1.]))-10/12)<1e-12)
checks['population_jaccard_expected']=bool(abs(r.jac(A,B,np.array([10.,1.,10.]))-1/21)<1e-12)
# Population residualization: residual orthogonal to intercept and zlog population.
pop=np.array([10,20,40,80,160,320.],float); z=(np.log1p(pop)-np.log1p(pop).mean())/np.log1p(pop).std(); s=2+0.7*z+np.array([.2,-.1,.05,-.05,.1,-.2])
mean,resid,coef,z2,ortho=r.population_mean_structure(s,pop)
checks['conditioning_z_reproducible']=bool(np.max(np.abs(z-z2))<1e-12)
checks['residual_orthogonality_pass']=bool(ortho<1e-10)
checks['mean_plus_residual_reconstructs_surface']=bool(np.max(np.abs(mean+resid-s))<1e-12)
# MSR sign-randomization preserves centered L2 norm.
W=np.ones((6,6))-np.eye(6); W=W/W.sum(1,keepdims=True); V=r.basis(W); ss=r.surrogates(resid,V,25,123)
base=np.linalg.norm(resid-resid.mean()); norms=np.linalg.norm(ss-ss.mean(1,keepdims=True),axis=1)
checks['msr_centered_l2_preserved']=bool(np.max(np.abs(norms-base))<1e-9)
checks['all_pass']=bool(all(bool(v) for k,v in checks.items() if k.endswith('_pass') or k.endswith('_expected') or k.endswith('_reproducible') or k.endswith('_surface') or k.endswith('_preserved')))
(ROOT/'dry_run'/'V2_METRIC_CONDITIONING_AUDIT.json').write_text(json.dumps(checks,indent=2),encoding='utf-8')
print(json.dumps(checks,indent=2))
if not checks['all_pass']: raise SystemExit('V2 guardrail audit failed')
