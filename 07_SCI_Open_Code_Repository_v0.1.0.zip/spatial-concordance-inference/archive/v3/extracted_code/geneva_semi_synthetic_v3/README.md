# Geneva semi-synthetic TBI demonstration — v3

This package implements the health case study for the Spatial Concordance Inference (SCI) methods paper.

## Design
1. Real public geography and population denominators: official Geneva SITG `OCS_POPULATION_SSECTEUR`, CH1903+/LV95 (EPSG:2056).
2. Published aggregate clinical margins only: N=1,071 total, N=393 age 18–59, N=678 age >=60.
3. Fully synthetic clinical geography: all risk fields, event allocations and spatial patterns are generated de novo from fixed random seeds.

No observed patient address, residential coordinate, empirical TBI hotspot polygon, cluster centroid, patient-level trajectory or unpublished spatial feature is used.

This is a methodological demonstration, NOT an empirical replication or new TBI localization analysis.

Official source: https://sitg.ge.ch/donnees/ocs-population-ssecteur

Published context: Ayma A, Legrand Q, Fellay N, et al. Am J Public Health. 2026;116(9):1272-1275. doi:10.2105/AJPH.2026.308560

## v3 inferential and source guardrails
The package now distinguishes three concordance estimands that must not be conflated:

- **Unit-count Jaccard**: each statistical subsector receives weight 1. This describes overlap by number of administrative units.
- **Area Jaccard**: each subsector is weighted by its exact planar polygon area in LV95 (m²). Polygon holes are subtracted and MultiPolygon parts are summed.
- **Population Jaccard**: each subsector is weighted by mapped adult population age 18+ (18–59 + >=60).

The area and unit-count statistics use the same unconditioned MSR surrogate ensemble. The population-weighted statistic uses a separate, pre-specified residual null:

`m_B = b0 + b1 * z(log(1 + P_18plus))`

The coefficients are estimated once from the observed synthetic B surface, the fitted mean is then held fixed, and MSR is applied only to the residual surface. This is a fixed-design conditional nuisance adjustment; it is not selected after inspection of the official synthetic maps.

All statistics sharing the same null reuse the same surrogate ensemble, avoiding artificial Monte-Carlo differences between equivalent metrics.

## Run
Install:

    pip install -r requirements.txt

Fetch official data (tries only official SITG/Geneva transports for the same dataset):

    python scripts/00_fetch_sitg_official.py

If all official transports fail, the script writes `data/SITG_FETCH_AUDIT.json` and stops. It never falls back to a non-official geography.

Validate:

    python scripts/01_validate_prepare_support.py --input data/OCS_POPULATION_SSECTEUR_EPSG2056.geojson --output-dir outputs/support

Application:

    python scripts/02_run_semi_synthetic_tbi.py --support outputs/support/prepared_support.geojson --config config_publication.json --output-dir outputs/application

Deterministic guardrail audit:

    python scripts/97_audit_metric_conditioning.py

Engine-only self-test, explicitly NOT Geneva:

    python scripts/98_dry_run_engine.py

## Guardrails
- the official input file is SHA-256 hashed;
- the support validator rejects non-LV95 coordinates;
- polygon area and centroid are recomputed from geometry rather than inferred from unit counts;
- the clinical margins are fixed before spatial simulation;
- the primary pattern is top 10% estimated risk;
- RR>1.5 is secondary and is NOT tuned to force estimability;
- all clinical geography is labeled `fully_synthetic`;
- non-estimability is reported rather than corrected post hoc;
- dry-run outputs are explicitly labeled `NOT_GENEVA`.

SITG caveat: some residents cannot be assigned to a statistical subsector because a complete locatable address is unavailable; mapped totals may be below canton-wide OCSTAT totals.


## Current source verification (2026-09-11)
Public SITG metadata confirms polygon geometry, EPSG:2056, GeoJSON query support, and the required age fields. The current hosted service exposes field names in lower case; the validator intentionally normalizes names before checking the schema. Metadata verification is not equivalent to ingestion of the feature data.
