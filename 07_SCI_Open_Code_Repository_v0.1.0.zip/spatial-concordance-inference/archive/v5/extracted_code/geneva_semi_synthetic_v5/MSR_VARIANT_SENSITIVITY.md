# Pre-execution MSR algorithm sensitivity — NOT Geneva

This audit was run entirely on the fictitious 158-unit support before official SITG ingestion. It used the health-application sample sizes (N=393 age 18–59; N=678 age ≥60), beta=0.8, 3.5-km latent range, 2.5-km kernel bandwidth, and B=499 null replicates. There were 2,000 repeated realizations per rho. Publication seeds were not used.

## Why this matters
The SCI implementation uses the singleton procedure of Wagner & Dray (2015): each nonconstant MEM coefficient keeps its magnitude and receives an independent random sign. This strictly preserves the MEM power spectrum and global Moran structure. The `adespatial::msr` family also provides pair-MSR, which randomly redistributes variance within adjacent MEM pairs and is less restrictive. A reviewer could reasonably ask whether conclusions are an artifact of the singleton choice.

## Results
Under H0 (rho=0), top-10% Type-I error was 4.15% for singleton and 4.55% for pair-MSR. For the RR>1.5 procedure, estimability was 92.3%; whole-procedure rejection was 4.55% and 4.65%, respectively (conditional among estimable realizations: 4.93% and 5.04%). Thus both algorithms were close to nominal in this audit.

At rho=.50, top-10% rejection/power was 14.45% for singleton versus 16.35% for pair-MSR. At rho=.65, it was 24.60% versus 27.10%. For RR>1.5 at rho=.65, whole-procedure power was 24.45% versus 27.50% (estimability 91.9%). Pair-MSR is therefore somewhat less conservative/more powerful here, but it does not overturn the inferential picture.

## Decision
Singleton MSR remains the primary SCI null because (i) the full confirmatory simulation program was calibrated with this strict null, (ii) it has a clear exact structure-preservation interpretation, and (iii) switching algorithms after seeing downstream results would create another degree of freedom. Pair-MSR is retained as an algorithmic sensitivity in the Supplement. The single Geneva semi-synthetic realization must not be described as a power validation.

See `validation_msr_variant/msr_variant_summary.csv` and `validation_msr_variant/msr_variant_manifest.json`.
