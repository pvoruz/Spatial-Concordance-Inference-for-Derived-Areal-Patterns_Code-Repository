# Geneva semi-synthetic TBI demonstration — v5

This package implements the health case study for the Spatial Concordance Inference (SCI) methods paper.

## Design
1. Real public geography and population denominators: official Geneva SITG `OCS_POPULATION_SSECTEUR`, CH1903+/LV95 (EPSG:2056).
2. Published aggregate clinical margins only: N=1,071 total, N=393 age 18–59, N=678 age >=60.
3. Fully synthetic clinical geography: all risk fields, event allocations and spatial patterns are generated de novo from fixed random seeds.

No observed patient address, residential coordinate, empirical TBI hotspot polygon, cluster centroid, patient-level trajectory or unpublished spatial feature is used. This is a methodological demonstration, NOT an empirical replication or new TBI localization analysis.

Official source: https://sitg.ge.ch/donnees/ocs-population-ssecteur

Published context: Ayma A, Legrand Q, Fellay N, et al. Am J Public Health. 2026;116(9):1272-1275. doi:10.2105/AJPH.2026.308560

## v5 inferential guardrails
Three concordance estimands remain distinct:

- **Unit-count Jaccard**: equal weight per statistical subsector.
- **True-area Jaccard**: exact planar polygon area in LV95 m²; holes are subtracted and MultiPolygon parts summed. **This is the primary inferential estimand in the application.**
- **Population Jaccard**: mapped adult population age 18+; secondary and explicitly nuisance-model-dependent.

Unit-count and true-area statistics reuse one common unconditioned MSR surrogate ensemble.

For population-weighted inference, the prespecified primary nuisance model is

`m_B = b0 + b1 * z(log(1 + P_18plus))`.

Coefficients are estimated once from the synthetic B surface, the fitted mean is held fixed, and MSR is applied to the residual. A **prospectively frozen cubic sensitivity**, added before official Geneva ingestion, uses the same population covariate with the fixed span

`1, z, centered(z^2), centered(z^3)`.

The linear and cubic conditional nulls reuse the exact same MSR sign matrix. If their significance decisions differ at alpha=0.05, the population-weighted inference is labeled **nuisance-model-dependent**; the favorable result must not be selected.

This sensitivity was motivated by independent fictional-support calibration: the fitted linear model was well calibrated when population dependence was approximately linear, but nonlinear misspecification could inflate Type-I error. The cubic sensitivity reduced that vulnerability across the screened nonlinear forms without being treated as universally validated. See `POPULATION_NUISANCE_VALIDATION.md`.

## Run
Install:

    pip install -r requirements.txt

Fetch official data (only official SITG/Geneva transports for the same dataset):

    python scripts/00_fetch_sitg_official.py

If all official transports fail, the script writes `data/SITG_FETCH_AUDIT.json` and stops. It never falls back to non-official geography.

Validate:

    python scripts/01_validate_prepare_support.py --input data/OCS_POPULATION_SSECTEUR_EPSG2056.geojson --output-dir outputs/support

Application:

    python scripts/02_run_semi_synthetic_tbi.py --support outputs/support/prepared_support.geojson --config config_publication.json --output-dir outputs/application

Verify blind publication seeds (does not execute the application):

    python scripts/93_verify_official_seed_derivation.py

Deterministic guardrail audit:

    python scripts/97_audit_metric_conditioning.py

Engine-only self-test, explicitly NOT Geneva and using a distinct test-only seed namespace:

    python scripts/98_dry_run_engine.py

Optional pre-execution MSR algorithm sensitivity (fictitious support only):

    python scripts/94_msr_variant_sensitivity.py

Reproduce nuisance-model stress tests:

    python scripts/96_population_nuisance_calibration.py
    python scripts/95_population_nuisance_basis_screen.py

## Blind publication-seed guardrail
The v4 publication seeds were retired before official SITG ingestion because they had already been executed in the fictitious dry-run. In v5, publication seeds are derived deterministically from a frozen SHA-256 rule documented in `OFFICIAL_SEED_DERIVATION.json`. These publication seeds must not be run on fictitious support before the first official Geneva execution. The engine dry-run derives a completely separate test-only seed namespace. This change is a prospective anti-post-selection guardrail, not a response to the eventual Geneva result.

## MSR algorithm specification
The primary continuous-surface null uses the **singleton Moran spectral randomization** procedure of Wagner and Dray: signs of nonconstant MEM coefficients are randomized independently, preserving the full MEM power spectrum and global Moran structure exactly for the chosen spatial operator. A pre-execution fictitious-support comparison against **pair-MSR** found similar H0 calibration but modestly higher power for pair-MSR. Singleton is retained because all prior confirmatory calibration and the core SCI estimand use that stricter null; pair-MSR is treated as an algorithmic sensitivity rather than a result-selection alternative. See `MSR_VARIANT_SENSITIVITY.md`.

The health-like repeated-realization audit also showed that the single semi-synthetic application is not a power-validation exercise: with N=393 vs 678 and rho=.65, procedure-level rejection was about 24.6% for singleton top-10% SCI and 27.1% for pair-MSR. Consequently, the Geneva realization must be interpreted as an illustrative operator-conditional demonstration irrespective of whether its single seeded p-value is significant.

## Guardrails
- official input is SHA-256 hashed;
- publication seeds are hash-derived, frozen before official ingestion, and never used in the dry-run;
- support validator rejects non-LV95 coordinates;
- exact polygon area/centroid are recomputed from geometry;
- clinical margins are frozen before spatial simulation;
- primary pattern is top 10% estimated risk;
- RR>1.5 is secondary and is not tuned to force estimability;
- true-area inference is primary; population weighting is secondary;
- linear and cubic population nuisance specifications are frozen before official ingestion;
- disagreement across nuisance specifications is reported, not resolved by result selection;
- all clinical geography is labeled `fully_synthetic`;
- non-estimability is reported rather than corrected post hoc;
- dry-run outputs are explicitly labeled `NOT_GENEVA`.

SITG caveat: some residents cannot be assigned to a statistical subsector because a complete locatable address is unavailable; mapped totals may be below canton-wide OCSTAT totals.

## Current source verification (2026-09-11)
Public SITG metadata confirms polygon geometry, EPSG:2056, GeoJSON query support and the required age fields. The hosted service currently exposes lower-case field names; the validator normalizes names before schema checking. Metadata verification is not equivalent to ingestion of raw feature data, and no Geneva result is claimed until raw official GeoJSON is ingested, hashed and validated.
