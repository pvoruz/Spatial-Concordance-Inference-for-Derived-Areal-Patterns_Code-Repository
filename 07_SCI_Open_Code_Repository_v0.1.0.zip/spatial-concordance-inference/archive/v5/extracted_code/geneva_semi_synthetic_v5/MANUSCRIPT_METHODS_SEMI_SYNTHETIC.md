# Manuscript-safe semi-synthetic health application — v5

The methodological case study uses a strict semi-synthetic design. Geographic support and population denominators are specified from the official Geneva SITG population-by-statistical-subsector layer (OCS_POPULATION_SSECTEUR; CH1903+/LV95, EPSG:2056), whereas all clinical geography is synthetic.

The synthetic sample is calibrated only to publicly reported aggregate characteristics of a Geneva hospitalized traumatic brain injury cohort: 1,071 hospitalized cases overall, including 678 adults aged 60 years or older and 393 adults aged 18–59 years. These counts constrain only the numbers of simulated events. No observed patient address, empirical hotspot polygon, cluster centroid, patient-level clinical trajectory, or unpublished spatial feature is used.

Within age stratum g,

(C_1g,...,C_mg) ~ Multinomial(N_g, pi_1g,...,pi_mg),

with

pi_ig = P_ig exp(beta R_ig) / sum_j P_jg exp(beta R_jg),

where P_ig is the official age-specific denominator and R_ig is a de novo seeded synthetic spatial-risk field generated independently of the empirical TBI map.

The primary pattern operator classifies the 10% of spatial units with the highest estimated log-relative risk. RR>1.5 is a secondary variable-mass operator and is not tuned if non-estimable.

Three overlap estimands are kept distinct. Unit-count Jaccard weights every statistical subsector equally. True-area Jaccard uses exact planar polygon area computed from the official LV95 geometry, with holes subtracted and MultiPolygon components summed. Population Jaccard weights each subsector by mapped adult population age 18 years or older. The true-area estimand is the primary inferential analysis in the semi-synthetic application; population-weighted inference is secondary.

For unit-count and true-area inference, a common continuous-surface singleton Moran spectral randomization (MSR) ensemble is generated and the prespecified pattern operator is reapplied to every surrogate. Singleton MSR independently randomizes the signs of nonconstant Moran-eigenvector coefficients, thereby preserving the power assigned to each MEM and the global Moran structure for the chosen spatial operator. A pair-MSR sensitivity audit was completed prospectively on fictitious support; it showed similar null calibration with modestly higher power, so singleton MSR was retained as the primary algorithm because the preceding confirmatory validation of SCI used this stricter null. For population-weighted inference, a separate fixed-design residual null is used. The prespecified primary nuisance model decomposes the senior log-relative-risk surface S_B as

S_B = m_B(P) + epsilon_B,

m_B(P) = b0 + b1 z[log(1 + P_18plus)].

The coefficients are estimated once from the synthetic B surface, the fitted mean is held fixed, and MSR is applied only to epsilon_B. Surrogate surfaces are reconstructed as S_B* = m_B(P) + epsilon_B*.

Because calibration experiments performed on fictitious non-Geneva support before official data ingestion showed that nonlinear misspecification of m_B(P) can inflate Type-I error, a prospective cubic sensitivity was frozen before the official application. It uses the same standardized population covariate z and the fixed polynomial span

m_B,cubic(P) = gamma_0 + gamma_1 z + gamma_2 [z^2 - mean(z^2)] + gamma_3 [z^3 - mean(z^3)].

The linear and cubic residual nulls reuse the same MSR sign matrix, so differences are attributable to nuisance specification rather than an independently drawn Monte-Carlo ensemble. The linear model remains the prespecified primary population-conditioned analysis; the cubic model is a sensitivity analysis rather than a replacement selected for fit. If the two population-conditioned analyses yield different significance decisions at alpha=0.05, population-weighted inference is designated nuisance-model-dependent and neither result is selected preferentially. The true-area result remains the primary application inference.

The same MSR surrogate ensemble is reused for all statistics sharing a null model. This avoids avoidable Monte-Carlo differences between equivalent or closely related statistics.

To prevent selection of a favorable stochastic realization, publication seeds were frozen by a deterministic SHA-256 derivation rule before official SITG feature ingestion. Seeds previously used during engine development were retired because their dry-run outputs had already been observed. The publication seeds are not executed on fictitious support; all software dry-runs use a separate test-only seed namespace. This separation makes the first execution on the official Geneva support prospectively blind with respect to the stochastic realization.

A repeated-realization pre-execution audit on fictitious support used the application sample sizes and model settings to characterize interpretation rather than to select seeds. At the application latent cross-field correlation (rho=.65), procedure-level rejection for the top-10% operator was approximately 24.6% under singleton MSR and 27.1% under pair-MSR. The semi-synthetic Geneva analysis is therefore treated as an illustrative real-support application of the prespecified operator and null, not as a validation of statistical power and not as evidence about empirical Geneva TBI geography.

This application is a real-geography simulation and methodological demonstration. It must not be interpreted as an empirical replication, validation, or new localization result for TBI in Geneva.
