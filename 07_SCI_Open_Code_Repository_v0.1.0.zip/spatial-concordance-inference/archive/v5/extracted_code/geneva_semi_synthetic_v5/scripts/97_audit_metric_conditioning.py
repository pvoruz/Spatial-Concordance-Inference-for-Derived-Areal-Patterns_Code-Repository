#!/usr/bin/env python3
"""Deterministic v5 guardrail tests for geometry, weights, nuisance models and shared MC signs."""
import importlib.util, json
from pathlib import Path
import numpy as np

ROOT=Path(__file__).resolve().parents[1]

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m
v=load('validator',ROOT/'scripts'/'01_validate_prepare_support.py')
r=load('runner',ROOT/'scripts'/'02_run_semi_synthetic_tbi.py')

checks={}
# 10x10 square with 2x2 hole -> area 96, centroid (5,5)
g={'type':'Polygon','coordinates':[
 [[0,0],[10,0],[10,10],[0,10],[0,0]],
 [[4,4],[6,4],[6,6],[4,6],[4,4]]
]}
a,c=v.geometry_metrics(g); checks['polygon_hole_area_pass']=bool(abs(a-96)<1e-9); checks['polygon_hole_centroid_pass']=bool(np.max(np.abs(c-[5,5]))<1e-9)
# MultiPolygon: square area 4 centered (1,1) + square area 1 centered (10.5,.5)
g2={'type':'MultiPolygon','coordinates':[
 [[[0,0],[2,0],[2,2],[0,2],[0,0]]],
 [[[10,0],[11,0],[11,1],[10,1],[10,0]]]
]}
a2,c2=v.geometry_metrics(g2); target=(4*np.array([1.,1.])+np.array([10.5,.5]))/5
checks['multipolygon_area_pass']=bool(abs(a2-5)<1e-9); checks['multipolygon_centroid_pass']=bool(np.max(np.abs(c2-target))<1e-9)
# Weighted Jaccard semantics.
A=np.array([1,1,0],bool); B=np.array([0,1,1],bool)
checks['unit_jaccard_expected']=bool(abs(r.jac(A,B)-1/3)<1e-12)
checks['area_jaccard_expected']=bool(abs(r.jac(A,B,np.array([1.,10.,1.]))-10/12)<1e-12)
checks['population_jaccard_expected']=bool(abs(r.jac(A,B,np.array([10.,1.,10.]))-1/21)<1e-12)
# Population nuisance designs are deterministic functions of fixed P only.
pop=np.array([10,20,40,80,160,320.],float)
z=(np.log1p(pop)-np.log1p(pop).mean())/np.log1p(pop).std()
s=2+0.7*z+0.15*(z**2-(z**2).mean())+np.array([.2,-.1,.05,-.05,.1,-.2])
mean1,resid1,coef1,z1,ortho1=r.population_mean_structure(s,pop,degree=1)
mean3,resid3,coef3,z3,ortho3=r.population_mean_structure(s,pop,degree=3)
X1,_,names1=r.population_design(pop,1); X3,_,names3=r.population_design(pop,3)
checks['conditioning_z_reproducible']=bool(np.max(np.abs(z-z1))<1e-12 and np.max(np.abs(z-z3))<1e-12)
checks['linear_residual_orthogonality_pass']=bool(ortho1<1e-10)
checks['cubic_residual_orthogonality_pass']=bool(ortho3<1e-10)
checks['linear_reconstruction_pass']=bool(np.max(np.abs(mean1+resid1-s))<1e-12)
checks['cubic_reconstruction_pass']=bool(np.max(np.abs(mean3+resid3-s))<1e-12)
checks['linear_design_names_pass']=bool(names1==['intercept','zlog1p'])
checks['cubic_design_names_pass']=bool(names3==['intercept','zlog1p','centered_zlog1p_sq','centered_zlog1p_cu'])
checks['cubic_design_outcome_independent_pass']=bool(np.max(np.abs(X3-r.population_design(pop*1.0,3)[0]))<1e-12)
# MSR sign randomization preserves centered L2 norm.
W=np.ones((6,6))-np.eye(6); W=W/W.sum(1,keepdims=True); V=r.basis(W)
signs=r.msr_sign_matrix(V.shape[1],25,123)
ss1=r.surrogates_with_signs(resid1,V,signs); ss3=r.surrogates_with_signs(resid3,V,signs)
base1=np.linalg.norm(resid1-resid1.mean()); base3=np.linalg.norm(resid3-resid3.mean())
norms1=np.linalg.norm(ss1-ss1.mean(1,keepdims=True),axis=1); norms3=np.linalg.norm(ss3-ss3.mean(1,keepdims=True),axis=1)
checks['msr_linear_centered_l2_preserved']=bool(np.max(np.abs(norms1-base1))<1e-9)
checks['msr_cubic_centered_l2_preserved']=bool(np.max(np.abs(norms3-base3))<1e-9)
checks['shared_sign_matrix_reproducible']=bool(np.array_equal(signs,r.msr_sign_matrix(V.shape[1],25,123)))
# Same outcome effect size must not depend on which conditional nuisance null is used.
hA=np.array([1,1,0,0,1,0],bool); q=0.5
ens1=mean1[None,:]+ss1; ens3=mean3[None,:]+ss3
j1,_,_=r.p_fixed_from_ensemble(hA,s,q,ens1,pop); j3,_,_=r.p_fixed_from_ensemble(hA,s,q,ens3,pop)
checks['population_effect_size_null_invariant_pass']=bool(abs(j1-j3)<1e-12)

eligible=lambda k: k.endswith('_pass') or k.endswith('_expected') or k.endswith('_reproducible') or k.endswith('_preserved')
checks['all_pass']=bool(all(bool(val) for k,val in checks.items() if eligible(k)))
out=ROOT/'dry_run'/'V5_METRIC_CONDITIONING_AUDIT.json'
out.write_text(json.dumps(checks,indent=2),encoding='utf-8')
print(json.dumps(checks,indent=2))
if not checks['all_pass']: raise SystemExit('V5 guardrail audit failed')
