#!/usr/bin/env python3
"""Pre-execution singleton-vs-pair MSR sensitivity on fictitious support.

This audit does NOT use publication seeds and does NOT produce Geneva results.
It tests the exact health-like sample sizes (393 vs 678), beta/range/bandwidth,
and two pattern operators under rho in {0,.50,.65}.
"""
from __future__ import annotations
import argparse, importlib.util, json, math
from pathlib import Path
import numpy as np, pandas as pd
from scipy.linalg import eigh
from scipy.spatial.distance import cdist
from scipy.stats import norm

ROOT=Path(__file__).resolve().parents[1]

def load_runner():
    spec=importlib.util.spec_from_file_location('runner',ROOT/'scripts'/'02_run_semi_synthetic_tbi.py')
    m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m
r=load_runner()

def mem_basis(W):
    S=(W+W.T)/2
    C=S-S.mean(1,keepdims=True)-S.mean(0,keepdims=True)+S.mean()
    lam,V=eigh(C,check_finite=False)
    # Remove the constant eigenvector explicitly so pair rotations can never create a mean shift.
    const_idx=int(np.argmax(np.abs(V.T@np.ones(len(V))/math.sqrt(len(V)))))
    keep=np.arange(len(lam))!=const_idx
    lam,V=lam[keep],V[:,keep]
    order=np.argsort(lam)[::-1]
    return lam[order],V[:,order],C

def singleton_ensemble(s,V,B,rng):
    z=s-s.mean(); c=V.T@z
    signs=rng.choice(np.array([-1.,1.]),size=(len(c),B))
    return (s.mean()+V@(c[:,None]*signs)).T

def pair_ensemble(s,V,B,rng):
    z=s-s.mean(); c=V.T@z
    out=np.empty((len(c),B),float)
    upto=len(c)-(len(c)%2)
    for j in range(0,upto,2):
        radius=float(np.hypot(c[j],c[j+1]))
        phi=rng.uniform(0,2*np.pi,size=B)
        out[j]=radius*np.cos(phi); out[j+1]=radius*np.sin(phi)
    if len(c)%2:
        out[-1]=c[-1]*rng.choice(np.array([-1.,1.]),size=B)
    return (s.mean()+V@out).T

def top_rows(S,k):
    idx=np.argpartition(S,S.shape[1]-k,axis=1)[:,S.shape[1]-k:]
    H=np.zeros(S.shape,bool); H[np.arange(S.shape[0])[:,None],idx]=True
    return H

def jaccard(a,b,w=None):
    if w is None: w=np.ones(len(a))
    inter=w[a&b].sum(); union=w[a|b].sum()
    return inter/union if union>0 else np.nan

def p_top(hA,sB,ens,k):
    hB=r.top(sB,k/len(sB)); obs=jaccard(hA,hB)
    HB=top_rows(ens,k); w=np.ones(len(hA)); wa=w*hA
    inter=HB@wa; wb=HB@w; den=wa.sum()+wb-inter
    null=inter/den
    return obs,(1+np.sum(null>=obs))/(len(ens)+1)

def p_abs(hA,sB,ens,thr):
    hB=sB>thr
    if hA.sum()==0 or hB.sum()==0: return np.nan,np.nan
    obs=jaccard(hA,hB); HB=ens>thr; w=np.ones(len(hA)); wa=w*hA
    inter=HB@wa; wb=HB@w; den=wa.sum()+wb-inter
    null=np.divide(inter,den,out=np.zeros_like(inter,float),where=den>0)
    return obs,(1+np.sum(null>=obs))/(len(ens)+1)

def wilson(k,n,alpha=.05):
    z=norm.ppf(1-alpha/2); ph=k/n; den=1+z*z/n
    ctr=(ph+z*z/(2*n))/den
    half=z*math.sqrt(ph*(1-ph)/n+z*z/(4*n*n))/den
    return ctr-half,ctr+half

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--reps',type=int,default=2000); ap.add_argument('--B',type=int,default=499)
    ap.add_argument('--outdir',default=str(ROOT/'validation_msr_variant')); args=ap.parse_args()
    out=Path(args.outdir); out.mkdir(parents=True,exist_ok=True)
    raw=json.loads((ROOT/'dry_run'/'synthetic_support_NOT_GENEVA.geojson').read_text())
    P=[f['properties'] for f in raw['features']]
    x=np.array([[q['SCI_CENTROID_X'],q['SCI_CENTROID_Y']] for q in P],float)
    pw=np.array([q['SCI_POP_18_59'] for q in P],float); ps=np.array([q['SCI_POP_60PLUS'] for q in P],float)
    W=r.graph(x,6); lam,V,C=mem_basis(W)
    D=cdist(x,x); L=np.linalg.cholesky(np.exp(-(D/3500.)**2)+np.eye(len(x))*1e-8)
    K=np.exp(-.5*(D/2500.)**2); denw=K@pw; dens=K@ps
    k=max(1,int(round(.10*len(x)))); thr=math.log(1.5)
    rows=[]
    for j,rho in enumerate([0.,.50,.65]):
        rng=np.random.default_rng(2026091301+j)
        rec=[]
        for rep in range(args.reps):
            g=L@rng.normal(size=len(x)); e=L@rng.normal(size=len(x))
            g=(g-g.mean())/g.std(); e=(e-e.mean())/e.std()
            rs=rho*g+math.sqrt(max(0.,1-rho*rho))*e; rs=(rs-rs.mean())/rs.std()
            ww=pw*np.exp(.8*g); ww/=ww.sum(); ws=ps*np.exp(.8*rs); ws/=ws.sum()
            cw=rng.multinomial(393,ww); cs=rng.multinomial(678,ws)
            sw=np.log(np.clip((K@cw/denw)/(cw.sum()/pw.sum()),1e-12,None))
            ss=np.log(np.clip((K@cs/dens)/(cs.sum()/ps.sum()),1e-12,None))
            hA=r.top(sw,.10); hAa=sw>thr
            es=singleton_ensemble(ss,V,args.B,np.random.default_rng(10_000_000+100000*j+rep))
            ep=pair_ensemble(ss,V,args.B,np.random.default_rng(20_000_000+100000*j+rep))
            Jobs,ps_top=p_top(hA,ss,es,k); _,pp_top=p_top(hA,ss,ep,k)
            Jabs,ps_abs=p_abs(hAa,ss,es,thr); _,pp_abs=p_abs(hAa,ss,ep,thr)
            rec.append((rep,Jobs,ps_top,pp_top,Jabs,ps_abs,pp_abs,int(hAa.sum()),int((ss>thr).sum())))
        d=pd.DataFrame(rec,columns=['rep','J_top','p_singleton_top','p_pair_top','J_rr15','p_singleton_rr15','p_pair_rr15','massA_rr15','massB_rr15'])
        d.to_csv(out/f'health_like_rho{rho:.2f}_replicates_reproduced.csv',index=False)
        for op,pS,pP in [('top10','p_singleton_top','p_pair_top'),('rr15','p_singleton_rr15','p_pair_rr15')]:
            for alg,pcol in [('singleton',pS),('pair',pP)]:
                estim=np.isfinite(d[pcol]); reject=estim & (d[pcol]<=.05); kk=int(reject.sum()); lo,hi=wilson(kk,len(d))
                rows.append({'rho':rho,'operator':op,'msr_algorithm':alg,'reps':len(d),'B':args.B,
                             'procedure_rejection_rate':kk/len(d),'ci95_low':lo,'ci95_high':hi,
                             'estimability':float(estim.mean()),
                             'conditional_rejection_rate':float((d.loc[estim,pcol]<=.05).mean()) if estim.any() else np.nan})
    summary=pd.DataFrame(rows); summary.to_csv(out/'msr_variant_summary_reproduced.csv',index=False)
    manifest={'status':'PREEXECUTION_MSR_VARIANT_AUDIT_COMPLETE','support':'synthetic_support_NOT_GENEVA.geojson','clinical_interpretation':False,
              'publication_seeds_used':False,'reps_per_rho':args.reps,'B':args.B,'alpha':.05,'rho_values':[0,.5,.65],
              'sample_sizes':{'N_18_59':393,'N_60plus':678},
              'singleton_definition':'independent sign randomization of each nonconstant MEM coefficient; strict singleton MSR',
              'pair_definition':'uniform random rotation within consecutive eigenvalue-ordered MEM pairs; pooled pair power preserved',
              'interpretation':'Algorithmic sensitivity only. Singleton remains primary because prior calibration and framework definitions used strict singleton MSR.'}
    (out/'msr_variant_reproduction_manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    print(summary.to_string(index=False))
if __name__=='__main__': main()
