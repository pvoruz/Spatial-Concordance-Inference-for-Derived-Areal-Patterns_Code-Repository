#!/usr/bin/env python3
import argparse, hashlib, json, math
from pathlib import Path
import numpy as np, pandas as pd
from scipy.linalg import eigh
from scipy.spatial.distance import cdist
from sklearn.neighbors import NearestNeighbors
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon

N_WORK=393; N_SEN=678

def sha(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        for b in iter(lambda:f.read(1048576),b''): h.update(b)
    return h.hexdigest()

def graph(x,k):
    _,idx=NearestNeighbors(n_neighbors=k+1).fit(x).kneighbors(x)
    A=np.zeros((len(x),len(x)))
    for i in range(len(x)):
        for j in idx[i,1:]: A[i,j]=A[j,i]=1
    if np.any(A.sum(1)==0): raise ValueError('Isolated spatial unit')
    return A/A.sum(1,keepdims=True)

def basis(W):
    S=(W+W.T)/2
    C=S-S.mean(1,keepdims=True)-S.mean(0,keepdims=True)+S.mean()
    return eigh(C,check_finite=False)[1]

def gp(x,rho,rng_m,seed):
    D=cdist(x,x); K=np.exp(-(D/rng_m)**2)+np.eye(len(x))*1e-8
    L=np.linalg.cholesky(K); r=np.random.default_rng(seed)
    g=L@r.normal(size=len(x)); e=L@r.normal(size=len(x))
    g=(g-g.mean())/g.std(); e=(e-e.mean())/e.std()
    s=rho*g+math.sqrt(max(0,1-rho*rho))*e; s=(s-s.mean())/s.std()
    return g,s

def draw(pop,risk,N,beta,seed):
    if pop.sum()<=0: raise ValueError('Population denominator sum is zero')
    w=pop*np.exp(beta*risk); w/=w.sum()
    return np.random.default_rng(seed).multinomial(N,w)

def smooth(c,pop,x,h):
    D=cdist(x,x); K=np.exp(-.5*(D/h)**2)
    den=K@pop
    if np.any(den<=0): raise ValueError('Kernel population denominator is non-positive')
    local=(K@c)/den
    return np.log(np.clip(local/(c.sum()/pop.sum()),1e-12,None))

def top(v,q):
    k=max(1,int(round(q*len(v)))); ix=np.argpartition(v,len(v)-k)[len(v)-k:]
    h=np.zeros(len(v),bool); h[ix]=1; return h

def jac(a,b,w=None):
    if w is None: w=np.ones(len(a),float)
    w=np.asarray(w,float); u=np.sum(w[a|b]); return np.sum(w[a&b])/u if u>0 else np.nan

def cont(a,b,w=None):
    if w is None: w=np.ones(len(a),float)
    w=np.asarray(w,float); d=np.sum(w[a]); return np.sum(w[a&b])/d if d>0 else np.nan

def surrogates(s,V,B,seed):
    z=s-s.mean(); c=V.T@z; r=np.random.default_rng(seed)
    active=np.abs(c)>1e-12
    signs=np.ones((len(c),B)); signs[active]=r.choice([-1.,1.],size=(active.sum(),B))
    return (s.mean()+V@(c[:,None]*signs)).T

def population_design(pop,degree=1):
    # Fixed-design basis defined only from mapped adult population, never from the outcome surface.
    lp=np.log1p(np.asarray(pop,float)); sd=lp.std()
    z=(lp-lp.mean())/(sd if sd>0 else 1.0)
    cols=[np.ones(len(z)),z]; names=['intercept','zlog1p']
    if degree>=2:
        z2=z**2; cols.append(z2-z2.mean()); names.append('centered_zlog1p_sq')
    if degree>=3:
        z3=z**3; cols.append(z3-z3.mean()); names.append('centered_zlog1p_cu')
    if degree not in (1,2,3): raise ValueError('Population nuisance polynomial degree must be 1, 2, or 3')
    return np.column_stack(cols),z,names

def population_mean_structure(s,pop,degree=1):
    # Primary: degree=1. Prospectively frozen sensitivity: degree=3.
    X,z,names=population_design(pop,degree)
    coef=np.linalg.lstsq(X,s,rcond=None)[0]
    mean=X@coef; resid=s-mean
    ortho=np.max(np.abs(X.T@resid))
    return mean,resid,coef,z,float(ortho)

def msr_sign_matrix(n_components,B,seed):
    # A common sign matrix can be reused across nuisance specifications to minimize avoidable MC noise.
    return np.random.default_rng(seed).choice([-1.,1.],size=(n_components,B))

def surrogates_with_signs(s,V,signs):
    z=s-s.mean(); c=V.T@z
    if signs.shape[0]!=len(c): raise ValueError('MSR sign matrix has incompatible component count')
    return (s.mean()+V@(c[:,None]*signs)).T

def surrogate_ensemble(s,V,B,seed,mean=None,signs=None):
    base=s if mean is None else s-mean
    ens=surrogates(base,V,B,seed) if signs is None else surrogates_with_signs(base,V,signs)
    return ens if mean is None else mean[None,:]+ens

def p_fixed_from_ensemble(hA,sB,q,ensemble,w=None):
    hB=top(sB,q); obs=jac(hA,hB,w)
    null=np.array([jac(hA,top(x,q),w) for x in ensemble])
    return obs,(1+(null>=obs).sum())/(len(ensemble)+1),null

def p_abs_from_ensemble(hA,sB,thr,ensemble,w=None):
    hB=sB>thr
    if hA.sum()==0 or hB.sum()==0: return np.nan,np.nan,hB,np.array([])
    obs=jac(hA,hB,w); null=[]
    for x in ensemble:
        hb=x>thr; z=jac(hA,hb,w); null.append(0 if not np.isfinite(z) else z)
    null=np.asarray(null)
    return obs,(1+(null>=obs).sum())/(len(ensemble)+1),hB,null

def mapfig(fs,val,path,title,label):
    vals=np.asarray(val,float); lo,hi=np.nanmin(vals),np.nanmax(vals)
    fig,ax=plt.subplots(figsize=(7.2,6)); cm=plt.get_cmap('viridis')
    for f,v in zip(fs,vals):
        parts=f['geometry']['coordinates']
        if f['geometry']['type']=='Polygon': parts=[parts]
        t=.5 if hi<=lo else (v-lo)/(hi-lo)
        for q in parts:
            xy=np.asarray(q[0],float)
            ax.add_patch(Polygon(xy,closed=True,facecolor=cm(t),edgecolor='black',linewidth=.2))
    ax.autoscale_view(); ax.set_aspect('equal'); ax.set_axis_off(); ax.set_title(title)
    sm=plt.cm.ScalarMappable(cmap=cm,norm=plt.Normalize(lo,hi)); sm.set_array([])
    fig.colorbar(sm,ax=ax,fraction=.035,pad=.02,label=label)
    fig.tight_layout(); fig.savefig(path,dpi=320,bbox_inches='tight'); plt.close(fig)

def _f(x): return None if not np.isfinite(x) else float(x)

def main():
    p=argparse.ArgumentParser(); p.add_argument('--support',required=True); p.add_argument('--config',required=True); p.add_argument('--output-dir',required=True)
    a=p.parse_args(); cfg=json.loads(Path(a.config).read_text()); out=Path(a.output_dir); out.mkdir(parents=True,exist_ok=True)
    raw=json.loads(Path(a.support).read_text()); fs=raw['features']; P=[f['properties'] for f in fs]
    x=np.asarray([[float(q['SCI_CENTROID_X']),float(q['SCI_CENTROID_Y'])] for q in P])
    area=np.asarray([float(q['SCI_AREA_M2']) for q in P]); pw=np.asarray([float(q.get('SCI_POP_18_59',0) or 0) for q in P]); ps=np.asarray([float(q.get('SCI_POP_60PLUS',0) or 0) for q in P]); padult=pw+ps
    support_mode=cfg.get('support_mode','official_geneva')
    # v5 blind-seed guardrail: publication seeds are reserved for the first official Geneva run.
    if support_mode!='official_geneva' and cfg.get('status')=='FROZEN_BEFORE_OFFICIAL_GENEVA_EXECUTION_V5_BLIND_SEEDS':
        raise ValueError('Blind v5 publication seeds cannot be executed on synthetic/dry-run support. Use the test-only dry-run configuration.')
    if not (2.3e6<x[:,0].min()<2.7e6 and 1.0e6<x[:,1].min()<1.3e6): raise ValueError('Support coordinates are not plausible LV95.')
    if support_mode=='official_geneva' and not all(q.get('SCI_SOURCE')=='SITG_OCS_POPULATION_SSECTEUR' for q in P): raise ValueError('Official mode requires validated SITG support.')
    if np.any(area<=0): raise ValueError('Non-positive polygon area')
    W=graph(x,int(cfg['spatial_graph_k'])); V=basis(W)
    rw,rs=gp(x,float(cfg['latent_cross_age_rho']),float(cfg['risk_spatial_range_m']),int(cfg['risk_seed']))
    cw=draw(pw,rw,N_WORK,float(cfg['beta']),int(cfg['event_seed_work'])); cs=draw(ps,rs,N_SEN,float(cfg['beta']),int(cfg['event_seed_senior']))
    if cw.sum()!=N_WORK or cs.sum()!=N_SEN: raise RuntimeError('Clinical margins not preserved')
    sw=smooth(cw,pw,x,float(cfg['kernel_bandwidth_m'])); ss=smooth(cs,ps,x,float(cfg['kernel_bandwidth_m']))
    q=float(cfg['primary_top_fraction']); hw=top(sw,q); hs=top(ss,q); B=int(cfg['nnull'])

    # Population-weighted inference is secondary and nuisance-model dependent by construction.
    # Primary nuisance specification: linear in z(log1p adult population).
    # Prospectively frozen sensitivity: cubic polynomial span in the same fixed population covariate.
    pop_mean,pop_resid,pop_coef,pop_z,pop_ortho=population_mean_structure(ss,padult,degree=1)
    pop_mean_cubic,pop_resid_cubic,pop_coef_cubic,pop_z_cubic,pop_ortho_cubic=population_mean_structure(ss,padult,degree=3)
    if np.max(np.abs(pop_z-pop_z_cubic))>1e-12: raise RuntimeError('Population nuisance designs use inconsistent z(log1p P)')

    # One common unconditioned MSR ensemble is reused across all unconditioned metrics/operators.
    ensemble_uncond=surrogates(ss,V,B,int(cfg['null_seed_unconditional']))
    # Linear and cubic conditional nulls reuse the exact same MSR sign matrix.
    pop_signs=msr_sign_matrix(V.shape[1],B,int(cfg['null_seed_population']))
    ensemble_pop_linear=surrogate_ensemble(ss,V,B,int(cfg['null_seed_population']),mean=pop_mean,signs=pop_signs)
    ensemble_pop_cubic=surrogate_ensemble(ss,V,B,int(cfg['null_seed_population']),mean=pop_mean_cubic,signs=pop_signs)

    ju,pu,_=p_fixed_from_ensemble(hw,ss,q,ensemble_uncond)
    ja,pa,_=p_fixed_from_ensemble(hw,ss,q,ensemble_uncond,area)
    jp,pp,_=p_fixed_from_ensemble(hw,ss,q,ensemble_pop_linear,padult)
    jp_cubic,pp_cubic,_=p_fixed_from_ensemble(hw,ss,q,ensemble_pop_cubic,padult)
    if abs(jp-jp_cubic)>1e-12: raise RuntimeError('Population Jaccard effect size changed across nuisance nulls')

    thr=math.log(float(cfg['secondary_rr_threshold'])); hwa=sw>thr
    ju2,pu2,hsa,_=p_abs_from_ensemble(hwa,ss,thr,ensemble_uncond)
    ja2,pa2,_,_=p_abs_from_ensemble(hwa,ss,thr,ensemble_uncond,area)
    jp2,pp2,_,_=p_abs_from_ensemble(hwa,ss,thr,ensemble_pop_linear,padult)
    jp2_cubic,pp2_cubic,_,_=p_abs_from_ensemble(hwa,ss,thr,ensemble_pop_cubic,padult)
    if np.isfinite(jp2) and np.isfinite(jp2_cubic) and abs(jp2-jp2_cubic)>1e-12:
        raise RuntimeError('Secondary population Jaccard effect size changed across nuisance nulls')
    nuisance_alpha=float(cfg.get('population_nuisance_sensitivity_alpha',0.05))
    primary_nuisance_dependence=bool((pp<=nuisance_alpha)!=(pp_cubic<=nuisance_alpha))
    secondary_nuisance_dependence=(None if not (np.isfinite(pp2) and np.isfinite(pp2_cubic))
                                  else bool((pp2<=nuisance_alpha)!=(pp2_cubic<=nuisance_alpha)))

    tab=pd.DataFrame({
        'ssecteur_7':[str(q.get('SSECTEUR_7',q.get('ssecteur_7',''))) for q in P],
        'area_m2':area,'population_18_59':pw,'population_60plus':ps,'population_18plus':padult,
        'population_conditioning_zlog1p':pop_z,
        'population_conditioning_linear_mean_logrr_60plus':pop_mean,
        'population_conditioning_linear_residual_logrr_60plus':pop_resid,
        'population_conditioning_cubic_mean_logrr_60plus':pop_mean_cubic,
        'population_conditioning_cubic_residual_logrr_60plus':pop_resid_cubic,
        'synthetic_cases_18_59':cw,'synthetic_cases_60plus':cs,
        'synthetic_latent_risk_18_59':rw,'synthetic_latent_risk_60plus':rs,
        'estimated_log_rr_18_59':sw,'estimated_log_rr_60plus':ss,
        'primary_hotspot_18_59':hw.astype(int),'primary_hotspot_60plus':hs.astype(int),
        'secondary_rr15_hotspot_18_59':hwa.astype(int),'secondary_rr15_hotspot_60plus':hsa.astype(int),
        'clinical_geography':'fully_synthetic'})
    tab.to_csv(out/'semi_synthetic_unit_results.csv',index=False)

    estim=bool(hwa.sum()>0 and hsa.sum()>0)
    res={
      'design':('real_geography_fully_synthetic_epidemiology' if support_mode=='official_geneva' else 'synthetic_support_engine_test_NOT_GENEVA'),'N_total':1071,'N_18_59':393,'N_60plus':678,
      'primary_pattern_rule':f'top {100*q:.1f}% of estimated log-relative-risk surface',
      'primary_unit_jaccard':float(ju),'primary_unit_p_sci':float(pu),
      'primary_area_jaccard':float(ja),'primary_area_p_sci':float(pa),
      'primary_population_jaccard':float(jp),
      'primary_population_p_conditional_sci':float(pp),
      'primary_population_p_conditional_sci_linear':float(pp),
      'primary_population_p_conditional_sci_cubic_sensitivity':float(pp_cubic),
      'primary_population_nuisance_model_dependence_at_alpha':primary_nuisance_dependence,
      'population_nuisance_sensitivity_alpha':nuisance_alpha,
      'population_conditioning_primary_formula':'m_B = b0 + b1*z(log1p(P_18plus)); fitted once; mean fixed; MSR on residual',
      'population_conditioning_sensitivity_formula':'cubic polynomial span: intercept + z + centered(z^2) + centered(z^3), where z=z(log1p(P_18plus)); fitted once; mean fixed; MSR on residual',
      'population_conditioning_decision_rule':'J_pop is secondary. If linear and cubic sensitivity cross the prespecified alpha in different directions, label population-weighted inference nuisance-model-dependent; do not select the favorable specification.',
      'population_conditioning_linear_coef':{n:float(v) for n,v in zip(population_design(padult,1)[2],pop_coef)},
      'population_conditioning_cubic_coef':{n:float(v) for n,v in zip(population_design(padult,3)[2],pop_coef_cubic)},
      'population_residual_orthogonality_linear_max_abs_Xt_e':pop_ortho,
      'population_residual_orthogonality_cubic_max_abs_Xt_e':pop_ortho_cubic,
      'containment_18_59_to_60plus_units':float(cont(hw,hs)), 'containment_60plus_to_18_59_units':float(cont(hs,hw)),
      'containment_18_59_to_60plus_area':float(cont(hw,hs,area)), 'containment_60plus_to_18_59_area':float(cont(hs,hw,area)),
      'containment_18_59_to_60plus_population':float(cont(hw,hs,padult)), 'containment_60plus_to_18_59_population':float(cont(hs,hw,padult)),
      'secondary_RR_threshold':float(cfg['secondary_rr_threshold']),'secondary_estimable':estim,
      'secondary_unit_jaccard':_f(ju2),'secondary_unit_p_sci':_f(pu2),
      'secondary_area_jaccard':_f(ja2),'secondary_area_p_sci':_f(pa2),
      'secondary_population_jaccard':_f(jp2),
      'secondary_population_p_conditional_sci':_f(pp2),
      'secondary_population_p_conditional_sci_linear':_f(pp2),
      'secondary_population_p_conditional_sci_cubic_sensitivity':_f(pp2_cubic),
      'secondary_population_nuisance_model_dependence_at_alpha':secondary_nuisance_dependence,
      'secondary_hotspot_units_18_59':int(hwa.sum()),'secondary_hotspot_units_60plus':int(hsa.sum()),
      'area_estimand_definition':'Jaccard weighted by exact LV95 polygon area in m^2; not by administrative-unit count',
      'population_estimand_definition':'Jaccard weighted by mapped adult population age 18+ (18-59 + 60+)',
      'unit_estimand_definition':'unweighted Jaccard over statistical subsectors'}
    (out/'results_summary.json').write_text(json.dumps(res,indent=2),encoding='utf-8')
    prov={'support_sha256':sha(Path(a.support)),'config_sha256':sha(Path(a.config)),
          'clinical_geography':'fully_synthetic','observed_patient_coordinates_used':False,'empirical_hotspot_geometry_used':False,
          'published_clinical_constraints':['N_total=1071','N_18_59=393','N_60plus=678'],
          'metric_guardrail':'unit-count, true-area, and population-weighted Jaccard are reported separately',
          'conditional_guardrail':'population-weighted inference is secondary: linear z(log1p mapped adult population) is the prespecified primary nuisance model; cubic polynomial in the same fixed covariate is a prospectively frozen sensitivity; same MSR sign matrix is reused across the two conditional nulls',
          'nuisance_model_disagreement_rule':'if linear and cubic significance decisions differ at the prespecified alpha, report J_pop inference as nuisance-model-dependent and do not select the favorable result',
          'support_mode':support_mode,'status':('SEMI_SYNTHETIC_METHOD_DEMONSTRATION' if support_mode=='official_geneva' else 'ENGINE_TEST_NOT_GENEVA')}
    (out/'provenance_manifest.json').write_text(json.dumps(prov,indent=2),encoding='utf-8')
    mapfig(fs,sw,out/'Figure_Synthetic_WorkingAge_LogRR.png','Semi-synthetic TBI risk — age 18–59','Estimated log relative risk')
    mapfig(fs,ss,out/'Figure_Synthetic_Senior_LogRR.png','Semi-synthetic TBI risk — age ≥60','Estimated log relative risk')
    print(json.dumps(res,indent=2))
if __name__=='__main__': main()
