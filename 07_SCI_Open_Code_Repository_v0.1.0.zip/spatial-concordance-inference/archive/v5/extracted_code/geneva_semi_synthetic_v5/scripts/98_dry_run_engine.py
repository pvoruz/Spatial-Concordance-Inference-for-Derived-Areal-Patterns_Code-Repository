#!/usr/bin/env python3
import hashlib, json, subprocess, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
subprocess.run([sys.executable,str(ROOT/'scripts'/'99_make_synthetic_support.py')],check=True)
cfg=json.loads((ROOT/'config_publication.json').read_text())
# CRITICAL: never execute publication seeds on fictitious support. Derive a separate test namespace.
test_salt='Spatial-Concordance-Inference|engine-dry-run|NOT-GENEVA|v5'
def seed(label):
    return int.from_bytes(hashlib.sha256((test_salt+'|'+label).encode()).digest()[:8],'big')%(2**32)
cfg.update({
    'risk_seed':seed('risk'),
    'event_seed_work':seed('event_18_59'),
    'event_seed_senior':seed('event_60plus'),
    'null_seed_unconditional':seed('null_unconditional'),
    'null_seed_population':seed('null_population'),
})
cfg['nnull']=199
cfg['support_mode']='synthetic_test_NOT_GENEVA'
cfg['status']='DRY_RUN_V5_ONLY_NOT_PUBLICATION'
cfg['publication_seeds_pretested_on_dry_run']=False
cfg['dry_run_seed_namespace']=test_salt
cfg['dry_run_seed_namespace_sha256']=hashlib.sha256(test_salt.encode()).hexdigest()
dcfg=ROOT/'dry_run'/'config_dry_run_v5.json'; dcfg.write_text(json.dumps(cfg,indent=2))
out=ROOT/'dry_run'/'v5_application'; out.mkdir(parents=True,exist_ok=True)
subprocess.run([sys.executable,str(ROOT/'scripts'/'02_run_semi_synthetic_tbi.py'),
                '--support',str(ROOT/'dry_run'/'synthetic_support_NOT_GENEVA.geojson'),
                '--config',str(dcfg),'--output-dir',str(out)],check=True)
res=json.loads((out/'results_summary.json').read_text())
qc={'status':'ENGINE_DRY_RUN_V5_NOT_GENEVA','support_features':len(json.loads((ROOT/'dry_run'/'synthetic_support_NOT_GENEVA.geojson').read_text())['features']),
    'synthetic_cases_total':res['N_total'],'synthetic_cases_18_59':res['N_18_59'],'synthetic_cases_60plus':res['N_60plus'],
    'unit_jaccard':res['primary_unit_jaccard'],'area_jaccard':res['primary_area_jaccard'],'population_jaccard':res['primary_population_jaccard'],
    'population_p_linear':res['primary_population_p_conditional_sci_linear'],
    'population_p_cubic_sensitivity':res['primary_population_p_conditional_sci_cubic_sensitivity'],
    'population_nuisance_model_dependence_at_alpha':res['primary_population_nuisance_model_dependence_at_alpha'],
    'secondary_estimable':res['secondary_estimable'],
    'publication_seeds_used':False,
    'dry_run_seed_namespace_sha256':cfg['dry_run_seed_namespace_sha256'],
    'all_clinical_geography_synthetic':True,'observed_patient_coordinates_used':False,'empirical_hotspot_geometry_used':False}
(ROOT/'dry_run'/'dry_run_QC_v5.json').write_text(json.dumps(qc,indent=2),encoding='utf-8')
print(json.dumps(qc,indent=2))
