#!/usr/bin/env python3
"""Fetch OCS_POPULATION_SSECTEUR from official Geneva endpoints only.

The scientific source is unchanged: SITG / Republic and Canton of Geneva,
OCS_POPULATION_SSECTEUR. Multiple official endpoints are attempted only as
transport fallbacks. No non-official mirror or substitute geography is allowed.
"""
from __future__ import annotations

import hashlib
import json
import socket
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "data" / "OCS_POPULATION_SSECTEUR_EPSG2056.geojson"
AUDIT = ROOT / "data" / "SITG_FETCH_AUDIT.json"
CATALOGUE = "https://sitg.ge.ch/donnees/ocs-population-ssecteur"

# All are official Geneva/SITG services for the same population layer.
ENDPOINTS = [
    {
        "name": "SITG vector service",
        "base": "https://vector.sitg.ge.ch/arcgis/rest/services/OCS_POPULATION_SSECTEUR/FeatureServer/0/query",
    },
    {
        "name": "Geneva hosted service",
        "base": "https://app2.ge.ch/tergeoservices/rest/services/Hosted/OCS_POPULATION_SSECTEUR/FeatureServer/0/query",
    },
    {
        "name": "SITG thematic administration service",
        "base": "https://thematic.sitg.ge.ch/arcgis/rest/services/ADMINISTRATION/FeatureServer/20/query",
    },
]
PARAMS = {
    "where": "1=1",
    "outFields": "*",
    "returnGeometry": "true",
    "outSR": "2056",
    "f": "geojson",
}
REQUIRED_LOWER = {
    "date_ref", "ssecteur_7", "pop", "age_18", "age_19", "age_20_24",
    "age_25_29", "age_30_34", "age_35_39", "age_40_44", "age_45_49",
    "age_50_54", "age_55_59", "age_60_64", "age_65_69", "age_70_74",
    "age_75_79", "age_80_84", "age_85_89", "age_90_94", "age_95_99",
    "age_100_plus",
}


def _sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _validate(data: bytes) -> dict:
    obj = json.loads(data)
    fs = obj.get("features", [])
    if obj.get("type") != "FeatureCollection" or not (100 <= len(fs) <= 1200):
        raise RuntimeError(
            f"Unexpected SITG response: type={obj.get('type')!r}, feature_count={len(fs)}"
        )
    fields = set()
    date_refs = set()
    pop_sum = 0.0
    for f in fs:
        props = f.get("properties") or {}
        low = {str(k).lower(): v for k, v in props.items()}
        fields.update(low)
        if low.get("date_ref") not in (None, ""):
            date_refs.add(str(low["date_ref"]))
        try:
            pop_sum += float(low.get("pop") or 0)
        except Exception:
            pass
    missing = sorted(REQUIRED_LOWER - fields)
    if missing:
        raise RuntimeError("Required fields missing: " + ", ".join(missing))
    return {
        "feature_count": len(fs),
        "date_ref_values": sorted(date_refs),
        "mapped_population_sum_from_POP": pop_sum,
        "required_fields_present": True,
        "field_name_case_normalized_for_validation": True,
    }


def main() -> None:
    OUT.parent.mkdir(parents=True, exist_ok=True)
    attempts = []
    accessed = datetime.now(timezone.utc).isoformat()

    for endpoint in ENDPOINTS:
        url = endpoint["base"] + "?" + urllib.parse.urlencode(PARAMS)
        attempt = {
            "name": endpoint["name"],
            "base": endpoint["base"],
            "query_url": url,
            "started_utc": datetime.now(timezone.utc).isoformat(),
        }
        try:
            host = urllib.parse.urlparse(url).hostname
            try:
                attempt["dns_addresses"] = sorted(
                    {x[4][0] for x in socket.getaddrinfo(host, 443, type=socket.SOCK_STREAM)}
                )
            except Exception as e:
                attempt["dns_error"] = f"{type(e).__name__}: {e}"

            req = urllib.request.Request(
                url, headers={"User-Agent": "Spatial-Concordance-Geneva/5.0"}
            )
            with urllib.request.urlopen(req, timeout=180) as r:
                data = r.read()
                attempt["http_status"] = getattr(r, "status", None)
                attempt["content_type"] = r.headers.get("Content-Type")
            validated = _validate(data)
            OUT.write_bytes(data)
            attempt.update({"status": "SUCCESS", "bytes": len(data), **validated})
            attempts.append(attempt)

            manifest = {
                "authority": "SITG / Republic and Canton of Geneva",
                "dataset": "OCS_POPULATION_SSECTEUR",
                "catalogue_url": CATALOGUE,
                "selected_official_endpoint": endpoint["name"],
                "query_url": url,
                "accessed_utc": accessed,
                "crs_requested": "EPSG:2056",
                "bytes": len(data),
                "sha256": _sha256(data),
                **validated,
                "status": "OFFICIAL_RAW_DOWNLOADED",
                "clinical_data_in_download": False,
                "transport_fallback_note": (
                    "Fallback endpoints are official Geneva/SITG services for the same dataset; "
                    "they do not change the scientific data source."
                ),
            }
            OUT.with_suffix(".fetch_manifest.json").write_text(
                json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8"
            )
            AUDIT.write_text(
                json.dumps({"status": "SUCCESS", "attempts": attempts}, indent=2, ensure_ascii=False),
                encoding="utf-8",
            )
            print(json.dumps(manifest, indent=2, ensure_ascii=False))
            return
        except Exception as e:
            attempt.update(
                {
                    "status": "FAILED",
                    "error_type": type(e).__name__,
                    "error": str(e),
                    "finished_utc": datetime.now(timezone.utc).isoformat(),
                }
            )
            attempts.append(attempt)

    report = {
        "status": "FAILED_ALL_OFFICIAL_ENDPOINTS",
        "dataset": "OCS_POPULATION_SSECTEUR",
        "authority": "SITG / Republic and Canton of Geneva",
        "catalogue_url": CATALOGUE,
        "attempts": attempts,
        "nonofficial_substitution_performed": False,
        "scientific_action": (
            "Stop official Geneva execution. Do not substitute another geography. "
            "Re-run in a network-enabled environment or provide the raw official GeoJSON."
        ),
    }
    AUDIT.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    raise SystemExit("All official SITG endpoints failed; see data/SITG_FETCH_AUDIT.json")


if __name__ == "__main__":
    main()
