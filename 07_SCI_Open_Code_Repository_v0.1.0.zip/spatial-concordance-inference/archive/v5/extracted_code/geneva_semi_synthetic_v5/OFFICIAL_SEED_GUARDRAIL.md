# Blind publication seed guardrail — v5

The v4 publication seeds were used during the fictitious engine dry-run. Once those outputs had been observed, the same seeds could no longer provide a fully blind stochastic realization for the official Geneva application. They were therefore retired before official SITG GeoJSON ingestion. This decision is based on prior exposure alone.

The v5 publication seeds are deterministic SHA-256 derivatives of the frozen string and labels documented in `OFFICIAL_SEED_DERIVATION.json`. The derivation is data-independent and can be independently recomputed with `scripts/93_verify_official_seed_derivation.py`.

A strict guardrail applies: the v5 publication seeds are not to be executed on any fictitious support before the first official Geneva run. `scripts/98_dry_run_engine.py` uses a different, explicitly test-only seed namespace.

For transparency only, a retrospective audit of the retired v4 realization is stored in `validation_msr_variant/retired_v4_seed_audit.json`. Its performance did not determine the v5 seeds.
