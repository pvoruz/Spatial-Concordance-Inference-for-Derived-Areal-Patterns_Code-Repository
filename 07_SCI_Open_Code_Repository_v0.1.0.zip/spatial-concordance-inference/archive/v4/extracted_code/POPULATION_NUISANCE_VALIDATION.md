# Population nuisance-model validation before official Geneva execution

## Why this check was added
Population-weighted Jaccard is a secondary estimand whose null must distinguish population structure from spatial concordance. The v3 package used a fixed-design linear nuisance model in standardized `log1p` adult population. Before any official Geneva feature data were ingested, we stress-tested whether estimating this nuisance mean and fixing it during MSR could distort Type-I error.

These simulations use fictitious non-Geneva support only. They are methodological calibration experiments, not health results.

## 1. Fitted versus known nuisance mean
With 1,000 null replications and B=199 MSR surrogates per replication:

| Nuisance data-generating process | Unconditional MSR | Known-mean oracle | Fitted linear MSR | Covariate-restricted fitted MSR |
|---|---:|---:|---:|---:|
| Application-scale linear | 0.062 | 0.054 | 0.054 | 0.054 |
| Moderate linear | 0.111 | 0.055 | 0.064 | 0.069 |
| Nonlinear, fitted as linear | 0.316 | 0.058 | 0.135 | 0.142 |

At the application-scale linear effect, the fitted linear procedure reproduced the oracle rejection rate. Under a stronger linear nuisance it was mildly anti-conservative. Under nonlinear misspecification, however, Type-I error inflation was material. Restricting MSR to the covariate-orthogonal subspace did not solve this functional-form problem and is therefore **not** adopted as the default procedure.

## 2. Prospective nuisance-basis screen
A separate pre-execution screen used 500 null replications and B=199 across six nuisance shapes. The cubic fitted model remained near the known-mean oracle across the screened shapes and reduced the severe inflation of the linear model under quadratic/asymmetric curvature. For example, under a quadratic nuisance the rejection rates were 0.176 (linear fitted), 0.086 (cubic fitted), and 0.070 (known-mean oracle). Under an asymmetric cubic nuisance they were 0.066, 0.056, and 0.054, respectively.

The cubic model was not uniformly exact and is **not** promoted to a universally validated replacement. Replacing the linear primary model after seeing an official Geneva realization would itself create model-selection bias.

## Frozen v4 decision
1. **Primary application inference remains true-area Jaccard**, not population-weighted Jaccard.
2. For `J_pop`, retain the original **linear** fixed-design nuisance model as the prespecified primary conditional analysis.
3. Add a prospectively frozen **cubic sensitivity** using the same standardized `log1p(P_18plus)` covariate and the span `1, z, centered(z^2), centered(z^3)`.
4. Linear and cubic conditional nulls reuse the **same MSR sign matrix** to reduce avoidable Monte-Carlo differences.
5. If their significance decisions differ at alpha=0.05, report population-weighted inference as **nuisance-model-dependent**. Do not select the favorable specification.
6. Do not adopt covariate-restricted MSR merely to force sample residual orthogonality; the simulations show that functional-form misspecification is the larger issue.

Raw summary files and the two reproducible simulation scripts are included in this package. The interrupted heavier B=499 experiment is intentionally excluded and is not part of the evidence base.
