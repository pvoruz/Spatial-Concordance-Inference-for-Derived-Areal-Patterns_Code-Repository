#!/usr/bin/env python3
"""Calibration audit for fitted population nuisance in population-weighted SCI.

This is a methodological stress test on the fictitious dry-run support, not a Geneva result.
It compares four one-sided top-10% population-weighted Jaccard nulls under H0 of
independent spatial residual fields conditional on a fixed population covariate:
  1) unconditional MSR on the full B surface;
  2) oracle-known nuisance mean + unrestricted MSR on the true residual;
  3) fitted nuisance mean + unrestricted MSR on the fitted residual (v2/v3 implementation);
  4) fitted nuisance mean + covariate-restricted MSR in Null(X^T).

The restricted MSR is an explicitly conditional target: fitted nuisance coefficients are
held fixed in every surrogate realization. It is not assumed a priori to be superior;
calibration is assessed empirically against an independent GP generator.
"""
from __future__ import annotations
import argparse, importlib.util, json, math
from pathlib import Path
import numpy as np, pandas as pd
from scipy.linalg import eigh, null_space
from scipy.spatial.distance import cdist

ROOT=Path(__file__).resolve().parents[1]

def load_runner():
    spec=importlib.util.spec_from_file_location('runner',ROOT/'scripts'/'02_run_semi_synthetic_tbi.py')
    m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m
r=load_runner()

def centered_operator(W):
    S=(W+W.T)/2
    return S-S.mean(1,keepdims=True)-S.mean(0,keepdims=True)+S.mean()

def restricted_basis(W,X):
    C=centered_operator(W)
    Q=null_space(X.T)
    lam,U=eigh(Q.T@C@Q,check_finite=False)
    V=Q@U
    return V,C

def top_rows(S,k):
    # S: B x n; returns bool B x n with exactly k positives per row.
    B,n=S.shape
    idx=np.argpartition(S,n-k,axis=1)[:,n-k:]
    H=np.zeros((B,n),dtype=bool)
    H[np.arange(B)[:,None],idx]=True
    return H

def jaccard_null(hA,S,w,k):
    HB=top_rows(S,k)
    wa=w*hA
    inter=HB@wa
    wb=HB@w
    wA=wa.sum()
    den=wA+wb-inter
    return np.divide(inter,den,out=np.zeros_like(inter,dtype=float),where=den>0)

def obs_jaccard(hA,sB,w,k):
    hB=r.top(sB,k/len(sB))
    return r.jac(hA,hB,w)

def p_from_surface_ensemble(hA,sB,ensemble,w,k):
    obs=obs_jaccard(hA,sB,w,k)
    null=jaccard_null(hA,ensemble,w,k)
    return (1+np.sum(null>=obs))/(len(null)+1),obs

def sign_ensemble(s,V,B,rng):
    z=s-s.mean(); c=V.T@z
    signs=rng.choice(np.array([-1.,1.]),size=(len(c),B))
    return (s.mean()+V@(c[:,None]*signs)).T

def restricted_sign_ensemble(resid,Vr,B,rng):
    c=Vr.T@resid
    signs=rng.choice(np.array([-1.,1.]),size=(len(c),B))
    return (Vr@(c[:,None]*signs)).T

def gp_draw(L,rng):
    e=L@rng.normal(size=L.shape[0])
    # Leave chance correlation with X intact; only center/standardize like a spatial field.
    e=e-e.mean(); sd=e.std()
    return e/(sd if sd>0 else 1.)

def fit_mean(s,X):
    b=np.linalg.lstsq(X,s,rcond=None)[0]
    m=X@b
    return m,s-m,b

def run_scenario(name,z,X,w,L,V,Vr,k,reps,B,alpha,seed,mean_fun):
    rng=np.random.default_rng(seed)
    rec=[]
    for rep in range(reps):
        eA=gp_draw(L,rng); eB=gp_draw(L,rng)
        mA,mB=mean_fun(z)
        sA=mA+eA; sB=mB+eB
        hA=r.top(sA,k/len(sA))
        mfit,efit,bfit=fit_mean(sB,X)

        # Independent Monte-Carlo streams by method but deterministic per replicate.
        rng_u=np.random.default_rng(seed+10_000_000+rep)
        rng_k=np.random.default_rng(seed+20_000_000+rep)
        rng_f=np.random.default_rng(seed+30_000_000+rep)
        rng_r=np.random.default_rng(seed+40_000_000+rep)

        ens_u=sign_ensemble(sB,V,B,rng_u)
        ens_known=mB[None,:]+sign_ensemble(eB,V,B,rng_k)
        ens_fit=mfit[None,:]+sign_ensemble(efit,V,B,rng_f)
        ens_restrict=mfit[None,:]+restricted_sign_ensemble(efit,Vr,B,rng_r)

        pu,obs=p_from_surface_ensemble(hA,sB,ens_u,w,k)
        pk,_=p_from_surface_ensemble(hA,sB,ens_known,w,k)
        pf,_=p_from_surface_ensemble(hA,sB,ens_fit,w,k)
        pr,_=p_from_surface_ensemble(hA,sB,ens_restrict,w,k)

        rec.append((rep,obs,pu,pk,pf,pr,float(bfit[1])))
    d=pd.DataFrame(rec,columns=['rep','J_obs','p_unconditional','p_known_mean','p_fitted_unrestricted','p_fitted_restricted','fitted_slope'])
    summ=[]
    for col,label in [
        ('p_unconditional','Unconditional full-surface MSR'),
        ('p_known_mean','Known nuisance mean + unrestricted residual MSR'),
        ('p_fitted_unrestricted','Fitted nuisance + unrestricted residual MSR'),
        ('p_fitted_restricted','Fitted nuisance + covariate-restricted residual MSR')]:
        p=d[col].to_numpy()
        rr=float(np.mean(p<=alpha)); se=math.sqrt(rr*(1-rr)/reps) if reps else float('nan')
        summ.append({'scenario':name,'method':label,'reps':reps,'B':B,'alpha':alpha,
                     'rejection_rate':rr,'mc_se_rejection':se,
                     'p_median':float(np.median(p)),'p_q10':float(np.quantile(p,.1)),'p_q90':float(np.quantile(p,.9))})
    return d,pd.DataFrame(summ)

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--reps',type=int,default=500); ap.add_argument('--B',type=int,default=199); ap.add_argument('--alpha',type=float,default=.05); ap.add_argument('--outdir',default=str(ROOT/'nuisance_calibration_screening'))
    args=ap.parse_args(); out=Path(args.outdir); out.mkdir(parents=True,exist_ok=True)

    raw=json.loads((ROOT/'dry_run'/'synthetic_support_NOT_GENEVA.geojson').read_text())
    P=[f['properties'] for f in raw['features']]
    x=np.array([[q['SCI_CENTROID_X'],q['SCI_CENTROID_Y']] for q in P],float)
    w=np.array([q['SCI_POP_18PLUS'] for q in P],float)
    lp=np.log1p(w); z=(lp-lp.mean())/lp.std(); X=np.column_stack([np.ones(len(z)),z])
    W=r.graph(x,6); V=r.basis(W); Vr,C=restricted_basis(W,X)
    D=cdist(x,x); K=np.exp(-(D/3500.)**2)+np.eye(len(x))*1e-8; L=np.linalg.cholesky(K)
    k=max(1,int(round(.10*len(x))))

    # Deterministic basis checks.
    basis_checks={
        'n_units':len(x),'restricted_basis_dim':Vr.shape[1],
        'max_abs_XtVr':float(np.max(np.abs(X.T@Vr))),
        'max_abs_VrtVr_minus_I':float(np.max(np.abs(Vr.T@Vr-np.eye(Vr.shape[1])))),
    }
    (out/'restricted_basis_checks.json').write_text(json.dumps(basis_checks,indent=2),encoding='utf-8')

    z2=z*z-np.mean(z*z)
    scenarios=[
      ('application_scale_linear', lambda z: (0.055*z,0.055*z)),
      ('moderate_linear', lambda z: (0.30*z,0.30*z)),
      ('nonlinear_misspecification', lambda z: (0.30*z+0.20*z2,0.30*z+0.20*z2)),
    ]
    summaries=[]
    for j,(name,fun) in enumerate(scenarios):
        d,s=run_scenario(name,z,X,w,L,V,Vr,k,args.reps,args.B,args.alpha,2026091200+100000*j,fun)
        d.to_csv(out/f'{name}_replicates.csv',index=False); summaries.append(s)
        print('\n'+name); print(s[['method','rejection_rate','mc_se_rejection','p_median']].to_string(index=False))
    allsum=pd.concat(summaries,ignore_index=True); allsum.to_csv(out/'summary.csv',index=False)
    manifest={'support':'synthetic_support_NOT_GENEVA.geojson','clinical_interpretation':False,'purpose':'nuisance-estimation calibration audit',
              'reps':args.reps,'B':args.B,'alpha':args.alpha,'hotspot_rule':'top 10% continuous surface','statistic':'population-weighted Jaccard',
              'residual_generator':'independent Gaussian-process fields, squared-exponential range 3.5 km','methods':allsum['method'].unique().tolist(),
              'note':'Screening/validation of inferential nuisance handling only; not a Geneva health result.'}
    (out/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')

if __name__=='__main__': main()
