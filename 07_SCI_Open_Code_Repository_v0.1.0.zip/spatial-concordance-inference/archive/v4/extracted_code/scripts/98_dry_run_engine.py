#!/usr/bin/env python3
import json, subprocess, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
subprocess.run([sys.executable,str(ROOT/'scripts'/'99_make_synthetic_support.py')],check=True)
cfg=json.loads((ROOT/'config_publication.json').read_text())
cfg['nnull']=199
cfg['support_mode']='synthetic_test_NOT_GENEVA'
cfg['status']='DRY_RUN_V4_ONLY_NOT_PUBLICATION'
dcfg=ROOT/'dry_run'/'config_dry_run_v4.json'; dcfg.write_text(json.dumps(cfg,indent=2))
out=ROOT/'dry_run'/'v4_application'; out.mkdir(parents=True,exist_ok=True)
subprocess.run([sys.executable,str(ROOT/'scripts'/'02_run_semi_synthetic_tbi.py'),
                '--support',str(ROOT/'dry_run'/'synthetic_support_NOT_GENEVA.geojson'),
                '--config',str(dcfg),'--output-dir',str(out)],check=True)
res=json.loads((out/'results_summary.json').read_text())
qc={'status':'ENGINE_DRY_RUN_V4_NOT_GENEVA','support_features':len(json.loads((ROOT/'dry_run'/'synthetic_support_NOT_GENEVA.geojson').read_text())['features']),
    'synthetic_cases_total':res['N_total'],'synthetic_cases_18_59':res['N_18_59'],'synthetic_cases_60plus':res['N_60plus'],
    'unit_jaccard':res['primary_unit_jaccard'],'area_jaccard':res['primary_area_jaccard'],'population_jaccard':res['primary_population_jaccard'],
    'population_p_linear':res['primary_population_p_conditional_sci_linear'],
    'population_p_cubic_sensitivity':res['primary_population_p_conditional_sci_cubic_sensitivity'],
    'population_nuisance_model_dependence_at_alpha':res['primary_population_nuisance_model_dependence_at_alpha'],
    'population_residual_orthogonality_linear_max_abs_Xt_e':res['population_residual_orthogonality_linear_max_abs_Xt_e'],
    'population_residual_orthogonality_cubic_max_abs_Xt_e':res['population_residual_orthogonality_cubic_max_abs_Xt_e'],
    'secondary_estimable':res['secondary_estimable'],
    'secondary_population_p_linear':res['secondary_population_p_conditional_sci_linear'],
    'secondary_population_p_cubic_sensitivity':res['secondary_population_p_conditional_sci_cubic_sensitivity'],
    'secondary_population_nuisance_model_dependence_at_alpha':res['secondary_population_nuisance_model_dependence_at_alpha'],
    'all_clinical_geography_synthetic':True,'observed_patient_coordinates_used':False,'empirical_hotspot_geometry_used':False}
(ROOT/'dry_run'/'dry_run_QC_v4.json').write_text(json.dumps(qc,indent=2),encoding='utf-8')
print(json.dumps(qc,indent=2))
