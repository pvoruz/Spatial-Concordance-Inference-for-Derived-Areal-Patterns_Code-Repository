#!/usr/bin/env python3
"""Screen fixed-design nuisance bases for population-conditioned weighted SCI.
Fictitious support only. No Geneva/clinical interpretation.
"""
from __future__ import annotations
import importlib.util, json, math
from pathlib import Path
import numpy as np, pandas as pd
from scipy.spatial.distance import cdist

ROOT=Path(__file__).resolve().parents[1]

def loadmod(name,path):
    s=importlib.util.spec_from_file_location(name,path); m=importlib.util.module_from_spec(s); s.loader.exec_module(m); return m
r=loadmod('runner',ROOT/'scripts/02_run_semi_synthetic_tbi.py')
cal=loadmod('cal',ROOT/'scripts/96_population_nuisance_calibration.py')

def design(z,degree):
    cols=[np.ones(len(z))]
    for d in range(1,degree+1):
        c=z**d
        # Center non-intercept columns for numerical stability; fit space is unchanged.
        c=c-c.mean()
        cols.append(c)
    X=np.column_stack(cols)
    # Standardize non-intercept columns; again, same span.
    for j in range(1,X.shape[1]):
        sd=X[:,j].std(); X[:,j]/=(sd if sd>0 else 1.)
    return X

def fit(s,X):
    b=np.linalg.lstsq(X,s,rcond=None)[0]; m=X@b; return m,s-m

def gp(L,rng):
    e=L@rng.normal(size=L.shape[0]); e-=e.mean(); e/=e.std(); return e

def run(name,mfun,z,w,L,V,reps,B,seed,k,alpha):
    rng=np.random.default_rng(seed); rows=[]
    X1=design(z,1); X2=design(z,2); X3=design(z,3)
    for rep in range(reps):
        eA=gp(L,rng); eB=gp(L,rng); mA,mB=mfun(z); sA=mA+eA; sB=mB+eB; hA=r.top(sA,k/len(sA))
        # Same sign stream for each fitted model within replicate -> paired MC noise as far as dimensions permit.
        pvals={}
        for deg,X in [(1,X1),(2,X2),(3,X3)]:
            mf,ef=fit(sB,X); rr=np.random.default_rng(seed+deg*10_000_000+rep); ens=mf[None,:]+cal.sign_ensemble(ef,V,B,rr)
            pvals[f'p_deg{deg}']=cal.p_from_surface_ensemble(hA,sB,ens,w,k)[0]
        rr=np.random.default_rng(seed+40_000_000+rep); ens=mB[None,:]+cal.sign_ensemble(eB,V,B,rr)
        pvals['p_oracle']=cal.p_from_surface_ensemble(hA,sB,ens,w,k)[0]
        rr=np.random.default_rng(seed+50_000_000+rep); ens=cal.sign_ensemble(sB,V,B,rr)
        pvals['p_uncond']=cal.p_from_surface_ensemble(hA,sB,ens,w,k)[0]
        rows.append({'rep':rep,**pvals})
    d=pd.DataFrame(rows); out=[]
    labels={'p_deg1':'linear fitted','p_deg2':'quadratic fitted','p_deg3':'cubic fitted','p_oracle':'known-mean oracle','p_uncond':'unconditional'}
    for c,l in labels.items():
        rr=float((d[c]<=alpha).mean()); se=math.sqrt(rr*(1-rr)/reps)
        out.append({'scenario':name,'model':l,'rejection_rate':rr,'mc_se':se,'p_median':float(d[c].median()),'reps':reps,'B':B})
    return d,pd.DataFrame(out)

def main():
    import argparse
    ap=argparse.ArgumentParser(); ap.add_argument('--reps',type=int,default=500); ap.add_argument('--B',type=int,default=199); ap.add_argument('--outdir',default=str(ROOT/'nuisance_basis_screen')); a=ap.parse_args()
    out=Path(a.outdir); out.mkdir(exist_ok=True,parents=True)
    raw=json.loads((ROOT/'dry_run/synthetic_support_NOT_GENEVA.geojson').read_text()); P=[f['properties'] for f in raw['features']]
    x=np.array([[q['SCI_CENTROID_X'],q['SCI_CENTROID_Y']] for q in P],float); w=np.array([q['SCI_POP_18PLUS'] for q in P],float)
    lp=np.log1p(w); z=(lp-lp.mean())/lp.std(); W=r.graph(x,6); V=r.basis(W); D=cdist(x,x); L=np.linalg.cholesky(np.exp(-(D/3500.)**2)+np.eye(len(x))*1e-8); k=max(1,int(round(.1*len(x))))
    z2=z*z-z.dot(z)/len(z) # simple centered square
    scenarios=[
      ('linear_application',lambda z:(.055*z,.055*z)),
      ('linear_moderate',lambda z:(.30*z,.30*z)),
      ('quadratic',lambda z:(.30*z+.20*(z*z-(z*z).mean()),.30*z+.20*(z*z-(z*z).mean()))),
      ('saturating',lambda z:(.38*np.tanh(.9*z),.38*np.tanh(.9*z))),
      ('asymmetric_cubic',lambda z:(.22*z+.06*(z**3-(z**3).mean()),.22*z+.06*(z**3-(z**3).mean()))),
      ('soft_threshold',lambda z:(.30/(1+np.exp(-4*(z-.35))),.30/(1+np.exp(-4*(z-.35))))),
    ]
    ss=[]
    for j,(name,fun) in enumerate(scenarios):
        d,s=run(name,fun,z,w,L,V,a.reps,a.B,2026091300+j*100000,k,.05); d.to_csv(out/f'{name}_replicates.csv',index=False); ss.append(s); print('\n'+name); print(s[['model','rejection_rate','mc_se','p_median']].to_string(index=False))
    S=pd.concat(ss,ignore_index=True); S.to_csv(out/'summary.csv',index=False)
    (out/'manifest.json').write_text(json.dumps({'support':'fictitious NOT GENEVA','purpose':'pre-execution nuisance-basis robustness screen','reps':a.reps,'B':a.B,'alpha':.05,'models':['linear','quadratic','cubic','known mean oracle','unconditional'],'scenario_names':[s[0] for s in scenarios]},indent=2),encoding='utf-8')
if __name__=='__main__': main()
