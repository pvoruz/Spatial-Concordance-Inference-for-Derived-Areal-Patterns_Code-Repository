#!/usr/bin/env python3
import argparse, hashlib, json
from pathlib import Path
import pandas as pd
import numpy as np

WORK=["age_18","age_19","age_20_24","age_25_29","age_30_34","age_35_39",
      "age_40_44","age_45_49","age_50_54","age_55_59"]
SEN=["age_60_64","age_65_69","age_70_74","age_75_79","age_80_84",
     "age_85_89","age_90_94","age_95_99","age_100_plus"]
REQ=set(["date_ref","ssecteur_7","pop"]+WORK+SEN)

def sha(p):
    h=hashlib.sha256()
    with open(p,"rb") as f:
        for b in iter(lambda:f.read(1048576),b""): h.update(b)
    return h.hexdigest()

def coords(x):
    if isinstance(x,(list,tuple)):
        if len(x)>=2 and all(isinstance(v,(int,float)) for v in x[:2]):
            yield float(x[0]),float(x[1])
        else:
            for q in x: yield from coords(q)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--input",required=True); ap.add_argument("--output-dir",required=True)
    a=ap.parse_args()
    inp=Path(a.input); out=Path(a.output_dir); out.mkdir(parents=True,exist_ok=True)
    raw=json.loads(inp.read_text())
    fs=raw.get("features",[])
    if raw.get("type")!="FeatureCollection" or not (100<=len(fs)<=1200):
        raise ValueError("Unexpected FeatureCollection / feature count.")
    rows=[]; xy=[]; seen=set(); outfs=[]
    for i,f in enumerate(fs):
        p={str(k).lower():v for k,v in f.get("properties",{}).items()}
        miss=REQ-set(p)
        if miss: raise ValueError(f"Feature {i} missing {sorted(miss)}")
        sid=str(p["ssecteur_7"])
        if sid in seen: raise ValueError(f"Duplicate SSECTEUR_7 {sid}")
        seen.add(sid)
        g=f.get("geometry")
        pts=list(coords(g.get("coordinates") if g else None))
        if not pts: raise ValueError(f"Empty geometry {sid}")
        xy.extend(pts)
        num=lambda k: 0.0 if p.get(k) is None else float(p[k])
        work=sum(num(k) for k in WORK); senior=sum(num(k) for k in SEN); pop=num("pop")
        if min(work,senior,pop)<0: raise ValueError("Negative denominator")
        P=dict(f.get("properties",{}))
        P["SCI_POP_18_59"]=work; P["SCI_POP_60PLUS"]=senior
        P["SCI_SOURCE"]="SITG_OCS_POPULATION_SSECTEUR"
        outfs.append({"type":"Feature","properties":P,"geometry":g})
        rows.append([sid,str(p["date_ref"]),pop,work,senior])
    z=np.asarray(xy,float); xmin,ymin=z.min(0); xmax,ymax=z.max(0)
    if not (2.3e6<xmin<2.7e6 and 2.3e6<xmax<2.7e6 and
            1.0e6<ymin<1.3e6 and 1.0e6<ymax<1.3e6):
        raise ValueError(f"Not plausible EPSG:2056 bounds: {xmin,ymin,xmax,ymax}")
    df=pd.DataFrame(rows,columns=["ssecteur_7","date_ref","pop","pop_18_59","pop_60plus"])
    dates=[x for x in df.date_ref.unique() if x and x.lower()!="none"]
    if len(dates)!=1: raise ValueError(f"Expected one DATE_REF, found {dates}")
    dest=out/"prepared_support.geojson"
    dest.write_text(json.dumps({"type":"FeatureCollection","features":outfs},separators=(",",":")))
    df.to_csv(out/"support_denominators.csv",index=False)
    m={"source":"SITG OCS_POPULATION_SSECTEUR","source_sha256":sha(inp),
       "prepared_sha256":sha(dest),"date_ref":dates[0],"feature_count":len(fs),
       "crs":"EPSG:2056","bounds":[xmin,ymin,xmax,ymax],
       "mapped_population_total":float(df["pop"].sum()),
       "mapped_population_18_59":float(df["pop_18_59"].sum()),
       "mapped_population_60plus":float(df["pop_60plus"].sum()),
       "zero_denominator_18_59":int((df.pop_18_59<=0).sum()),
       "zero_denominator_60plus":int((df.pop_60plus<=0).sum()),
       "status":"OFFICIAL_SUPPORT_VALIDATED"}
    (out/"support_manifest.json").write_text(json.dumps(m,indent=2))
    print(json.dumps(m,indent=2))
if __name__=="__main__": main()
