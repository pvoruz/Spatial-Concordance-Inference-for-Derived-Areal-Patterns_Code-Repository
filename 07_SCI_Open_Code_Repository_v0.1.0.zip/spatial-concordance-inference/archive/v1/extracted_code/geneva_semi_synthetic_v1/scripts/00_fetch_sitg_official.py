#!/usr/bin/env python3
import hashlib, json, urllib.request
from pathlib import Path

URL=("https://vector.sitg.ge.ch/arcgis/rest/services/Hosted/"
     "OCS_POPULATION_SSECTEUR/MapServer/0/query?"
     "where=1%3D1&outFields=*&returnGeometry=true&outSR=2056&f=geojson")
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/"data"/"OCS_POPULATION_SSECTEUR.geojson"

def main():
    OUT.parent.mkdir(parents=True,exist_ok=True)
    req=urllib.request.Request(URL,headers={"User-Agent":"Spatial-Concordance-Geneva/1.0"})
    with urllib.request.urlopen(req,timeout=180) as r:
        data=r.read()
    obj=json.loads(data)
    if obj.get("type")!="FeatureCollection" or len(obj.get("features",[]))<100:
        raise RuntimeError("Unexpected SITG response.")
    OUT.write_bytes(data)
    manifest={"url":URL,"bytes":len(data),
              "sha256":hashlib.sha256(data).hexdigest(),
              "feature_count":len(obj["features"]),"status":"OFFICIAL_RAW_DOWNLOADED"}
    OUT.with_suffix(".fetch_manifest.json").write_text(json.dumps(manifest,indent=2))
    print(json.dumps(manifest,indent=2))
if __name__=="__main__": main()
