#!/usr/bin/env python3
import json, math
from pathlib import Path
import numpy as np, pandas as pd
from scipy.spatial.distance import cdist
ROOT=Path(__file__).resolve().parents[1]
raw=json.loads((ROOT/"dry_run"/"synthetic_support_NOT_GENEVA.geojson").read_text())
cfg=json.loads((ROOT/"config_publication.json").read_text())
fs=raw["features"]; p=[x["properties"] for x in fs]
x=np.asarray([np.asarray(f["geometry"]["coordinates"][0][:-1]).mean(0) for f in fs],float)
pw=np.asarray([q["SCI_POP_18_59"] for q in p],float); ps=np.asarray([q["SCI_POP_60PLUS"] for q in p],float)
D=cdist(x,x); K=np.exp(-(D/float(cfg["risk_spatial_range_m"]))**2)+np.eye(len(x))*1e-8
L=np.linalg.cholesky(K); rng=np.random.default_rng(int(cfg["risk_seed"]))
g=L@rng.normal(size=len(x)); e=L@rng.normal(size=len(x)); g=(g-g.mean())/g.std(); e=(e-e.mean())/e.std()
rho=float(cfg["latent_cross_age_rho"]); s=rho*g+math.sqrt(1-rho*rho)*e; s=(s-s.mean())/s.std()
def draw(pop,risk,N,seed):
    q=pop*np.exp(float(cfg["beta"])*risk); q/=q.sum()
    return np.random.default_rng(seed).multinomial(N,q)
cw=draw(pw,g,393,int(cfg["event_seed_work"])); cs=draw(ps,s,678,int(cfg["event_seed_senior"]))
G=np.exp(-.5*(D/float(cfg["kernel_bandwidth_m"]))**2)
def surf(c,pop):
    return np.log(np.clip((G@c)/(G@pop)/(c.sum()/pop.sum()),1e-12,None))
sw=surf(cw,pw); ss=surf(cs,ps)
def top(v,q):
    k=max(1,int(round(q*len(v)))); ix=np.argpartition(v,len(v)-k)[len(v)-k:]
    h=np.zeros(len(v),bool); h[ix]=1; return h
hw=top(sw,.1); hs=top(ss,.1); j=(hw&hs).sum()/(hw|hs).sum()
rr=float(cfg["secondary_rr_threshold"]); aw=sw>math.log(rr); ass=ss>math.log(rr)
qc={"status":"ENGINE_DRY_RUN_NOT_GENEVA","support_features":len(fs),
    "synthetic_cases_total":int(cw.sum()+cs.sum()),"synthetic_cases_18_59":int(cw.sum()),
    "synthetic_cases_60plus":int(cs.sum()),"primary_top10_jaccard":float(j),
    "secondary_RR_threshold":rr,"secondary_hotspot_cells_18_59":int(aw.sum()),
    "secondary_hotspot_cells_60plus":int(ass.sum()),
    "all_clinical_geography_synthetic":True,"observed_patient_coordinates_used":False,
    "empirical_hotspot_geometry_used":False}
(ROOT/"dry_run"/"dry_run_QC.json").write_text(json.dumps(qc,indent=2))
pd.DataFrame({"fake_unit":[q["SSECTEUR_7"] for q in p],"synthetic_cases_18_59":cw,
              "synthetic_cases_60plus":cs,"estimated_log_rr_18_59":sw,
              "estimated_log_rr_60plus":ss}).to_csv(ROOT/"dry_run"/"dry_run_unit_results.csv",index=False)
print(json.dumps(qc,indent=2))
