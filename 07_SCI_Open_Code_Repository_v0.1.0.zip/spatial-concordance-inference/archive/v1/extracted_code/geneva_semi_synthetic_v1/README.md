# Geneva semi-synthetic TBI demonstration — v1

This package implements the health case study for the Spatial Concordance Inference methods paper.

## Design
1. Real public geography and population denominators: official Geneva SITG
   `OCS_POPULATION_SSECTEUR`, CH1903+/LV95 (EPSG:2056).
2. Published aggregate clinical margins only: N=1,071 total, N=393 age 18–59,
   N=678 age >=60.
3. Fully synthetic clinical geography: all risk fields, event allocations and spatial
   patterns are generated de novo from fixed random seeds.

No observed patient address, residential coordinate, empirical TBI hotspot polygon,
cluster centroid, patient-level trajectory or unpublished spatial feature is used.

This is a methodological demonstration, NOT an empirical replication or new TBI
localization analysis.

Official source:
https://sitg.ge.ch/donnees/ocs-population-ssecteur

Published context:
Ayma A, Legrand Q, Fellay N, et al. Am J Public Health. 2026;116(9):1272-1275.
doi:10.2105/AJPH.2026.308560

## Run
Install:
    pip install -r requirements.txt

Fetch official data:
    python scripts/00_fetch_sitg_official.py

Validate:
    python scripts/01_validate_prepare_support.py --input data/OCS_POPULATION_SSECTEUR.geojson --output-dir outputs/support

Application:
    python scripts/02_run_semi_synthetic_tbi.py --support outputs/support/prepared_support.geojson --config config_publication.json --output-dir outputs/application

Engine-only self-test, explicitly NOT Geneva:
    python scripts/99_make_synthetic_support.py
    python scripts/98_dry_run_engine.py

## Guardrails
- the official input file is SHA-256 hashed;
- the support validator rejects non-LV95 coordinates;
- the clinical margins are fixed before spatial simulation;
- the primary pattern is top 10% estimated risk;
- RR>1.5 is secondary and is NOT tuned to force estimability;
- all clinical geography is labeled `fully_synthetic`;
- non-estimability is reported rather than corrected post hoc.

SITG caveat: some residents cannot be assigned to a statistical subsector because
a complete locatable address is unavailable; mapped totals may be below canton-wide
OCSTAT totals.
