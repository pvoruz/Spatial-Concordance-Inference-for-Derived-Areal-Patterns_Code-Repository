# AI disclosure text for submission materials

## Full statement

Generative AI tools (OpenAI ChatGPT) were used during study development as assistive tools for manuscript drafting and editing, methodological organization and critique, code drafting/refactoring and debugging, preparation of figure-generation code, and repository/documentation development. AI-generated content was not treated as scientific evidence, a primary literature source, or an independently valid statistical result. The authors determined the scientific questions and inferential targets, reviewed and verified the code and numerical outputs supporting the manuscript, checked literature claims against primary sources, and take full responsibility for the accuracy and conclusions of the work. The public repository explicitly distinguishes archived original scripts from later AI-assisted clean or reconstructed implementations. No AI system is listed as an author.

## Short statement

Generative AI (OpenAI ChatGPT) was used to assist with writing/editing, code drafting and debugging, figure/repository preparation, and methodological organization. All scientific decisions, code and results supporting the manuscript were reviewed and verified by the authors, who take full responsibility for the work.

## Cover-letter sentence

We transparently disclose that generative AI was used as an assistive tool for writing, code development/debugging, and research-documentation tasks; all scientific decisions and reported analyses were reviewed and verified by the authors.
