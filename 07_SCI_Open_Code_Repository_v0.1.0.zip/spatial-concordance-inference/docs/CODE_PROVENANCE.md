# Code provenance and completeness

This repository intentionally distinguishes historical code from later cleaned/reconstructed code.

| Component | Status | Location |
|---|---|---|
| Official Geneva semi-synthetic analysis | **Archived original** | `scripts/official_application/` |
| SITG acquisition / validation | **Archived original** | `scripts/official_application/00_*`, `01_*` |
| Seed verification | **Archived original** | `scripts/official_application/93_*` |
| Singleton vs pair-MSR sensitivity | **Archived original** | `scripts/official_application/94_*` |
| Population nuisance screens/calibration | **Archived original** | `scripts/official_application/95_*`, `96_*` |
| Metric-conditioning audit | **Archived original** | `scripts/official_application/97_*` |
| Dry-run/synthetic-support engine | **Archived original** | `scripts/official_application/98_*`, `99_*` |
| v1–v5 development snapshots | **Archived originals** | `archive/v1/` … `archive/v5/` |
| Core reusable SCI functions | **Clean implementation** | `src/sci/` |
| Earlier benchmark simulation scripts | **Reconstructed reference implementations** | `scripts/reference_simulations/` |
| Publication/supplement figure scripts | **Clean documented implementations** | `scripts/figures/` |

## Why this distinction matters

Some early simulation analyses were developed interactively and are not all preserved as standalone historical scripts. Reconstructed code is therefore labelled as reconstructed and is not presented as if it were the historical file that generated a manuscript number.

The manuscript's numerical claims remain anchored to the versioned methodological audit trail and archived result tables.

## AI-assisted code

Generative AI assisted with drafting/refactoring parts of the clean/reconstructed code and documentation. This does **not** change the provenance label: archived originals remain untouched; AI-assisted later code is explicitly separate. See `AI_USE_DISCLOSURE.md`.
