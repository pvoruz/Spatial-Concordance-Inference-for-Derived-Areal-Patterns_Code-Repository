# Reproducibility guide

## Archived official application

The `scripts/official_application/` directory contains original scripts from the frozen v5 official analysis bundle.

Recommended order:

1. Obtain the public SITG support using `00_fetch_sitg_official.py`.
2. Validate/normalize using `01_validate_prepare_support.py`.
3. Verify publication-seed derivation with `93_verify_official_seed_derivation.py`.
4. Run `02_run_semi_synthetic_tbi.py` using `configs/config_publication.json`.
5. Compare outputs against `reference_outputs/results_summary.json`.

Do not change publication seeds or frozen application parameters if exact archived-specification reproduction is intended.

## Software environment

`requirements-lock.txt` captures the current environment after the official run. It is a future reproducibility aid, not retrospective evidence of the exact environment used during the first official run.

## Historical simulations

Where the original standalone source file was not preserved, a reconstructed reference implementation is supplied and labelled accordingly. Re-running and freezing these reconstructed experiments would be a valuable release-stage enhancement.

## SPARR

The SPARR bridge remains protocol-only and is not represented as validated code/results until executed and audited.
