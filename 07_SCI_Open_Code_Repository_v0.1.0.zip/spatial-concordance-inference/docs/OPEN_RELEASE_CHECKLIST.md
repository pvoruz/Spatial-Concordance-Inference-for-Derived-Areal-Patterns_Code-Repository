# Open release checklist

- [ ] Confirm author/contributor list.
- [ ] Confirm institutional/co-author approval for MIT licensing.
- [ ] Add manuscript DOI when available.
- [ ] Create GitHub repository and push this tree.
- [ ] Enable Zenodo-GitHub integration.
- [ ] Create a tagged release (`v1.0.0` recommended for the paper release).
- [ ] Archive the release in Zenodo and add DOI to `CITATION.cff`.
- [ ] Preserve `AI_USE_DISCLOSURE.md` in the public release.
- [ ] Add final journal-specific AI disclosure to the manuscript/submission system.
- [ ] Add final immutable environment snapshot.
- [ ] If reconstructed simulations are rerun, archive outputs and hashes.
- [ ] Keep patient-level/empirical clinical geography excluded.
- [ ] Keep the reverse Geneva direction labelled post hoc.
- [ ] Keep SPARR labelled protocol-only until executed/audited.
