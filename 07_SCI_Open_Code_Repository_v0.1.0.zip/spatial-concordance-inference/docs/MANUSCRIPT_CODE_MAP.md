# Manuscript-to-code map

| Manuscript component | Code / provenance |
|---|---|
| Weighted Jaccard estimands | `src/sci/metrics.py` |
| Fixed/absolute pattern operators | `src/sci/patterns.py` |
| kNN spatial graph / MSR | `src/sci/spatial.py` |
| Exact-N multinomial generator / Gaussian log RR | `src/sci/simulate.py` |
| Population-conditioned nuisance model | `src/sci/nuisance.py`; archived scripts `95_*`, `96_*` |
| Official Geneva application | `scripts/official_application/02_run_semi_synthetic_tbi.py` |
| Support acquisition/validation | archived scripts `00_*`, `01_*` |
| Seed verification | archived script `93_*` |
| Singleton/pair MSR sensitivity | archived script `94_*` |
| Population nuisance basis/calibration | archived scripts `95_*`, `96_*` |
| Metric-conditioning audit | archived script `97_*` |
| Dry-run / synthetic support | archived scripts `98_*`, `99_*` |
| Fixed-/variable-mass clean demos | `scripts/reference_simulations/` (reconstructed) |
| Summary figures from documented values | `scripts/figures/` |
| Full analytical chronology / evidence matrix | `docs/audit/Spatial_Concordance_Methodological_Development_Living_Table_v20.xlsx` |

The presence of a clean implementation does not imply that it was the historical source file used to generate a manuscript result. See `CODE_PROVENANCE.md`.
